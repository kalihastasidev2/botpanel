<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$admin = require_admin();
$all = pm2_all();

$servers = db()->query(
    'SELECT s.*, u.username FROM servers s JOIN users u ON u.id = s.user_id ORDER BY s.id DESC'
)->fetchAll();

foreach ($servers as $i => $s) {
    $servers[$i]['live'] = sync_status($s, $all);
}

render_layout_start('Tüm Sunucular', 'admin_servers');
page_heading('Tüm Sunucular', 'Sistemdeki tüm botları denetleyin, zorla durdurun veya silin.');
?>
<div class="<?= card_class() ?> overflow-hidden p-0">
  <div class="overflow-x-auto">
    <table class="w-full min-w-[860px] text-left text-sm">
      <thead class="border-b border-ink-700 bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500">
        <tr>
          <th class="px-5 py-3 font-medium">Bot</th>
          <th class="px-5 py-3 font-medium">Sahip</th>
          <th class="px-5 py-3 font-medium">Tür</th>
          <th class="px-5 py-3 font-medium">Durum</th>
          <th class="px-5 py-3 font-medium">CPU / RAM</th>
          <th class="px-5 py-3 font-medium text-right">Yönetim</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-ink-700">
      <?php foreach ($servers as $s): $m = $all[pm2_name((int)$s['id'])] ?? null; ?>
        <tr class="hover:bg-ink-700/20">
          <td class="px-5 py-4">
            <a href="server_detail.php?id=<?= (int)$s['id'] ?>" class="font-semibold text-white hover:text-brand-300"><?= e($s['bot_name']) ?></a>
            <p class="text-xs text-slate-500">#<?= (int)$s['id'] ?> · <?= e(basename($s['folder_path'])) ?></p>
          </td>
          <td class="px-5 py-4 text-slate-300"><?= e($s['username']) ?></td>
          <td class="px-5 py-4"><?= type_badge($s['bot_type']) ?></td>
          <td class="px-5 py-4"><?= status_badge($s['live']) ?></td>
          <td class="px-5 py-4 font-mono text-xs text-slate-400"><?= $m ? round($m['cpu'], 1) . '% · ' . round($m['memory'] / 1048576, 1) . ' MB' : '—' ?></td>
          <td class="px-5 py-4">
            <div class="flex flex-wrap justify-end gap-2">
              <?= action_button((int)$s['id'], 'start', 'Başlat', 'success', 'admin') ?>
              <?= action_button((int)$s['id'], 'stop', 'Zorla Durdur', 'warn', 'admin') ?>
              <?= action_button((int)$s['id'], 'delete', 'Sil', 'danger', 'admin', 'Bu sunucu ve dosyaları kalıcı olarak silinecek. Emin misiniz?') ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$servers): ?>
        <tr><td colspan="6" class="px-5 py-10 text-center text-slate-500">Sistemde sunucu yok.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php render_layout_end();
