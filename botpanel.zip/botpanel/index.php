<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();
$all = pm2_all();

$st = db()->prepare('SELECT * FROM servers WHERE user_id = ? ORDER BY id DESC');
$st->execute([$user['id']]);
$servers = $st->fetchAll();

$active = 0;
$cpuTotal = 0.0;
$ramTotal = 0;
$ramLimitTotal = 0;
foreach ($servers as $i => $srv) {
    $servers[$i]['live'] = sync_status($srv, $all);
    if ($servers[$i]['live'] === 'running') {
        $active++;
    }
    $m = $all[pm2_name((int)$srv['id'])] ?? null;
    if ($m) {
        $cpuTotal += $m['cpu'];
        $ramTotal += $m['memory'];
    }
    $ramLimitTotal += (int)$srv['ram_limit'];
}

$cpuLimitTotal = array_sum(array_column($servers, 'cpu_limit')) ?: 100;
$cpuPct = min(100, (int)round($cpuTotal / max(1, $cpuLimitTotal) * 100));
$ramPct = $ramLimitTotal > 0 ? min(100, (int)round($ramTotal / ($ramLimitTotal * 1024 * 1024) * 100)) : 0;
$ramMb = round($ramTotal / 1024 / 1024, 1);

$st = db()->prepare(
    'SELECT l.action, l.timestamp, s.bot_name FROM logs l
     JOIN servers s ON s.id = l.server_id
     WHERE s.user_id = ? ORDER BY l.id DESC LIMIT 8'
);
$st->execute([$user['id']]);
$recent = $st->fetchAll();

render_layout_start('Dashboard', 'index');
page_heading('Hoş geldin, ' . $user['username'], 'Botlarının durumu ve kaynak kullanımı');
?>

<section class="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
  <div class="<?= card_class() ?>">
    <p class="text-sm text-slate-400">Aktif Bot</p>
    <p class="mt-2 text-3xl font-semibold text-white"><?= $active ?><span class="text-lg text-slate-500"> / <?= count($servers) ?></span></p>
    <p class="mt-2 text-xs text-slate-500"><?= $all === null ? 'PM2 bağlantısı yok' : 'PM2 canlı veri' ?></p>
  </div>

  <div class="<?= card_class() ?>">
    <div class="flex items-center justify-between"><p class="text-sm text-slate-400">CPU Kullanımı</p><span class="text-sm font-semibold text-sky-300"><?= $cpuPct ?>%</span></div>
    <div class="mt-4 h-2 overflow-hidden rounded-full bg-ink-900"><div class="h-full rounded-full bg-gradient-to-r from-sky-500 to-cyan-300" style="width: <?= $cpuPct ?>%"></div></div>
    <p class="mt-3 text-xs text-slate-500">Toplam CPU limitine oranla</p>
  </div>

  <div class="<?= card_class() ?>">
    <div class="flex items-center justify-between"><p class="text-sm text-slate-400">RAM Kullanımı</p><span class="text-sm font-semibold text-violet-300"><?= $ramMb ?> MB</span></div>
    <div class="mt-4 h-2 overflow-hidden rounded-full bg-ink-900"><div class="h-full rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-400" style="width: <?= $ramPct ?>%"></div></div>
    <p class="mt-3 text-xs text-slate-500">Toplam RAM limitinin %<?= $ramPct ?>'i</p>
  </div>

  <div class="<?= card_class() ?>">
    <p class="text-sm text-slate-400">Bakiye</p>
    <p class="mt-2 text-3xl font-semibold text-brand-300"><?= e(money((float)$user['balance'])) ?></p>
    <p class="mt-2 text-xs text-slate-500">Yeni bot ücreti: <?= e(money(BOT_CREATE_COST)) ?></p>
  </div>
</section>

<section class="mt-8 grid gap-6 xl:grid-cols-3">
  <div class="<?= card_class() ?> xl:col-span-1">
    <h2 class="text-lg font-semibold text-white">Hızlı Bot Sihirbazı</h2>
    <p class="mt-1 text-sm text-slate-400">Adı ve türü seçin, dosyalar otomatik hazırlansın.</p>
    <form method="post" action="create_server.php" class="mt-6 space-y-5">
      <?= csrf_field() ?>
      <div>
        <label class="mb-1.5 block text-sm text-slate-400" for="qname">Bot adı</label>
        <input id="qname" name="name" required minlength="3" maxlength="40" placeholder="Örn: Destek Botu" class="<?= input_class() ?>">
      </div>
      <fieldset class="grid grid-cols-2 gap-3">
        <legend class="sr-only">Bot türü</legend>
        <label class="cursor-pointer rounded-xl border border-ink-600 bg-ink-900 p-4 text-sm has-[:checked]:border-lime-400 has-[:checked]:bg-lime-500/10">
          <input type="radio" name="type" value="nodejs" checked class="sr-only"><span class="block font-semibold text-white">Node.js</span><span class="text-xs text-slate-500">index.js</span>
        </label>
        <label class="cursor-pointer rounded-xl border border-ink-600 bg-ink-900 p-4 text-sm has-[:checked]:border-sky-400 has-[:checked]:bg-sky-500/10">
          <input type="radio" name="type" value="python" class="sr-only"><span class="block font-semibold text-white">Python</span><span class="text-xs text-slate-500">bot.py</span>
        </label>
      </fieldset>
      <input type="hidden" name="ram" value="256">
      <input type="hidden" name="cpu" value="100">
      <button type="submit" class="<?= btn_class() ?> w-full" <?= $user['balance'] < BOT_CREATE_COST ? 'disabled' : '' ?>>Bot Oluştur (<?= e(money(BOT_CREATE_COST)) ?>)</button>
    </form>
  </div>

  <div class="<?= card_class() ?> xl:col-span-2">
    <div class="mb-4 flex items-center justify-between">
      <h2 class="text-lg font-semibold text-white">Botlarım</h2>
      <a href="servers.php" class="text-sm text-brand-400 hover:text-brand-300">Tümünü gör →</a>
    </div>
    <?php if (!$servers): ?>
      <p class="rounded-xl bg-ink-900/70 p-6 text-center text-sm text-slate-500">Henüz bir botunuz yok. Soldaki sihirbazla ilk botunuzu oluşturun.</p>
    <?php else: ?>
      <ul class="divide-y divide-ink-700">
        <?php foreach (array_slice($servers, 0, 6) as $s): ?>
        <li class="flex flex-wrap items-center justify-between gap-3 py-3">
          <div class="min-w-0">
            <a href="server_detail.php?id=<?= (int)$s['id'] ?>" class="font-semibold text-white hover:text-brand-300"><?= e($s['bot_name']) ?></a>
            <p class="text-xs text-slate-500"><?= e($s['main_file']) ?> · RAM <?= (int)$s['ram_limit'] ?> MB</p>
          </div>
          <div class="flex items-center gap-3"><?= type_badge($s['bot_type']) ?><?= status_badge($s['live']) ?></div>
        </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</section>

<section class="<?= card_class() ?> mt-8">
  <h2 class="mb-4 text-lg font-semibold text-white">Son İşlemler</h2>
  <?php if (!$recent): ?>
    <p class="text-sm text-slate-500">Henüz işlem kaydı yok.</p>
  <?php else: ?>
    <div class="overflow-x-auto">
      <table class="w-full text-left text-sm">
        <thead class="text-xs uppercase tracking-wider text-slate-500"><tr><th class="pb-3 font-medium">Zaman</th><th class="pb-3 font-medium">Bot</th><th class="pb-3 font-medium">İşlem</th></tr></thead>
        <tbody class="divide-y divide-ink-700">
        <?php foreach ($recent as $r): ?>
          <tr><td class="py-2.5 text-slate-500"><?= e($r['timestamp']) ?></td><td class="py-2.5 text-slate-200"><?= e($r['bot_name']) ?></td><td class="py-2.5 font-mono text-xs text-slate-400"><?= e($r['action']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<?php render_layout_end();
