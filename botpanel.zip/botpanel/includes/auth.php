<?php
declare(strict_types=1);

/**
 * Oturumdaki kullanıcıyı döndürür. Hesap askıya alınmışsa oturumu kapatır.
 */
function current_user(): ?array
{
    static $resolved = false;
    static $user = null;

    if ($resolved) {
        return $user;
    }
    $resolved = true;

    if (empty($_SESSION['uid'])) {
        return null;
    }

    $st = db()->prepare('SELECT id, username, role, balance, status, api_key, created_at FROM users WHERE id = ?');
    $st->execute([(int)$_SESSION['uid']]);
    $row = $st->fetch();

    if (!$row || $row['status'] !== 'active') {
        logout_user();
        return null;
    }
    $user = $row;
    return $user;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        flash('error', 'Devam etmek için giriş yapmalısınız.');
        redirect('login.php');
    }
    return $user;
}

function require_admin(): array
{
    $user = require_login();
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        exit('Bu sayfaya erişim yetkiniz yok.');
    }
    return $user;
}

function login_user(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    unset($_SESSION['csrf']);
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

/**
 * İşlem geçmişi kaydı. $serverId null olabilir (kullanıcı/admin işlemleri).
 */
function add_log(?int $serverId, string $action): void
{
    $st = db()->prepare('INSERT INTO logs (server_id, action) VALUES (?, ?)');
    $st->execute([$serverId, mb_substr($action, 0, 255)]);
}
