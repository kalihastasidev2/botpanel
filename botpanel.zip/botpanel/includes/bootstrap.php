<?php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

// Kurulum tamamlanmadıysa install.php'ye yönlendir
if (!is_file(dirname(__DIR__) . '/install.lock')) {
    header('Location: install.php');
    exit;
}

require_once dirname(__DIR__) . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/pm2.php';
require_once __DIR__ . '/servers.php';
require_once __DIR__ . '/layout.php';

ini_set('display_errors', '0');
error_reporting(E_ALL);
start_session_safe();
