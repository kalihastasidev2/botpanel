# Karasipahi Tek - Bot Hosting Paneli

Node.js ve Python botlarını PM2 ile çalıştırmak, dosyalarını tarayıcıdan yönetmek,
canlı konsol izlemek ve müşteri/destek süreçlerini yönetmek için PHP 8.1+ & MySQL/MariaDB tabanlı panel.

## Gereksinimler

- PHP 8.1+ (`pdo_mysql`, `json`, `session` eklentileri)
- Apache (mod_rewrite) veya Nginx (aşağıdaki not bakın)
- MySQL 8 / MariaDB 10.4+
- Node.js 18+ ve `npm`, `pm2` (`npm i -g pm2`)
- Python 3 ve `pip` (Python botları için)
- PHP'nin `exec()` fonksiyonunun açık olması (PM2 ve otomatik kurulum için)

## Kurulum

1. Dosyaları web kök dizinine (örn. `/var/www/html/botpanel`) çıkarın.
2. `servers_data/` ve kök dizinin web kullanıcısı (`www-data`) tarafından yazılabilir olduğundan emin olun.
3. Tarayıcıdan `https://alanadiniz/botpanel/install.php` adresine gidin.
4. Sihirbaz:
   - MySQL/MariaDB yoksa otomatik kurar, root şifresini ayarlar, `botpanel` veritabanını ve tablolarını oluşturur.
   - Varsayılan admin: **kullanıcı adı** `admin`, **şifre** `Osman575761.`
5. Kurulum bitince `install.php` dosyasını **mutlaka silin**. `install.lock` dosyası tekrar kurulumu engeller.
6. Panele `login.php` üzerinden giriş yapın ve admin şifresini değiştirin.

### Otomatik kurulum için yetki
Otomatik MariaDB kurulumu `apt/dnf/yum` ve `systemctl` çağırır. Web kullanıcısının bunlara
`sudo -n` ile erişebilmesi gerekir. Örnek (`/etc/sudoers.d/botpanel`):

```
www-data ALL=(ALL) NOPASSWD: /usr/bin/apt-get, /usr/bin/dnf, /usr/bin/yum, /usr/bin/systemctl, /usr/bin/mysql, /usr/bin/npm
```

## PM2 notları

- Her bot `bot_{ID}` adıyla PM2'ye eklenir; port çakışması yoktur.
- `PM2_HOME` değeri `config.php` içinde tanımlıdır (kurulum sırasında otomatik tespit edilir).
- RAM limiti `--max-memory-restart` ile uygulanır.
- CPU limiti şu an bilgi amaçlıdır; zorlama için cgroups/cpulimit gerekir.
- Sunucu yeniden başladığında botları otomatik açmak için: `pm2 startup` komutunu çalıştırın ve `pm2 save` ile listeyi kaydedin.

## Dizin yapısı

```
botpanel/
├── config.php              # Sabitler ve DB bilgileri (install.php yazar)
├── install.php             # Sihirli kurulum
├── includes/
│   ├── bootstrap.php       # Tüm katmanları yükler
│   ├── helpers.php         # CSRF, flash, JSON, yönlendirme
│   ├── db.php              # PDO bağlantısı
│   ├── auth.php            # Oturum, yetki, işlem günlüğü
│   ├── pm2.php             # PM2 ve shell sarmalayıcıları
│   ├── servers.php         # Bot oluşturma/silme/dosya işlemleri
│   └── layout.php          # Tailwind koyu tema arayüz bileşenleri
├── servers_data/           # Her botun benzersiz klasörü (web erişimi kapalı)
├── index.php               # Müşteri dashboard
├── servers.php             # Bot listesi
├── server_detail.php       # Bot yönetimi, dosya editörü, canlı konsol
├── create_server.php       # Bot oluşturma sihirbazı
├── action.php              # Başlat/durdur/sil/dosya işlemleri + log API
├── profile.php             # Şifre ve API anahtarı
├── api.php                 # Salt okunur JSON API (Bearer anahtar)
├── support.php             # Müşteri destek talepleri
├── admin.php               # Yönetim özeti
├── admin_users.php         # Müşteri, bakiye, askı, silme
├── admin_servers.php       # Tüm botları denetleme
└── admin_tickets.php       # Destek yanıtlama
```

## Veritabanı

| Tablo           | Açıklama                                                                 |
|-----------------|--------------------------------------------------------------------------|
| users           | id, username, password (hash), role, balance, status, api_key, created_at |
| servers         | id, user_id, bot_name, bot_type, folder_path, main_file, status, ram_limit, cpu_limit, created_at |
| tickets         | id, user_id, subject, message, status, created_at                         |
| ticket_replies  | Destek yanıtları (konuşma akışı için)                                    |
| logs            | id, server_id, action, timestamp                                          |

## API örneği

```bash
curl -H "Authorization: Bearer <API_ANAHTARINIZ>" https://alanadiniz/botpanel/api.php
```

## Nginx kullanıyorsanız

`includes/`, `servers_data/` ve `config.php` dizinlerine dışarıdan erişimi engelleyin:

```nginx
location ~ ^/(includes|servers_data)/ { deny all; }
location = /config.php { deny all; }
location ~ \.(md|lock)$ { deny all; }
```

## Güvenlik kontrol listesi

- [ ] `install.php` silindi
- [ ] Admin şifresi değiştirildi
- [ ] HTTPS aktif
- [ ] `servers_data/` ve `config.php` web'den erişilemiyor
- [ ] Bot klasörleri için `0777` yetkisi yalnızca izole bir ortamda kullanılmalı; üretimde bot sahibi kullanıcıya `0750` tercih edin
