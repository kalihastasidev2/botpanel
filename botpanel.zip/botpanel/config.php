<?php
/*
 * Karasipahi Tek - Bot Hosting Paneli
 * Bu dosya install.php tarafından otomatik olarak yeniden yazılır.
 */
declare(strict_types=1);

define('APP_NAME', 'Karasipahi Tek');
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'botpanel');
define('DB_USER', 'botpanel');
define('DB_PASS', '');

define('SERVERS_DIR', __DIR__ . '/servers_data');
define('PM2_HOME', '/var/www/.pm2');
define('MAX_SERVERS_PER_USER', 5);
define('BOT_CREATE_COST', 25.00);
