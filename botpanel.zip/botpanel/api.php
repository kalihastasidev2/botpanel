<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

// Salt okunur API: kullanıcının botlarının durumunu döndürür.
// Kimlik doğrulama: Authorization: Bearer <api_key>  veya  X-API-Key: <api_key>
$key = '';
if (!empty($_SERVER['HTTP_AUTHORIZATION']) && preg_match('/Bearer\s+([a-f0-9]{64})/i', $_SERVER['HTTP_AUTHORIZATION'], $m)) {
    $key = $m[1];
} elseif (!empty($_SERVER['HTTP_X_API_KEY'])) {
    $key = (string)$_SERVER['HTTP_X_API_KEY'];
}

if (!preg_match('/^[a-f0-9]{64}$/', $key)) {
    json_out(['error' => 'API anahtarı eksik veya geçersiz.'], 401);
}

$st = db()->prepare("SELECT id, username FROM users WHERE api_key = ? AND status = 'active'");
$st->execute([$key]);
$owner = $st->fetch();
if (!$owner) {
    json_out(['error' => 'API anahtarı geçersiz.'], 401);
}

$st = db()->prepare(
    'SELECT id, bot_name, bot_type, status, ram_limit, cpu_limit, created_at FROM servers WHERE user_id = ? ORDER BY id'
);
$st->execute([$owner['id']]);
$servers = $st->fetchAll();

$all = pm2_all();
foreach ($servers as $i => $srv) {
    $servers[$i]['status'] = sync_status($srv, $all);
    $servers[$i]['id'] = (int)$srv['id'];
}

json_out([
    'user'    => $owner['username'],
    'count'   => count($servers),
    'servers' => $servers,
]);
