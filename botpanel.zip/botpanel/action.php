<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();
$do = (string)($_REQUEST['do'] ?? '');
$serverId = (int)($_REQUEST['server_id'] ?? 0);
$srv = $serverId > 0 ? fetch_server($serverId) : null;

// Canlı log / durum (AJAX, salt okunur)
if ($do === 'logs') {
    if (!$srv || !can_manage($srv, $user)) {
        json_out(['error' => 'Yetkisiz erişim.'], 403);
    }
    $all = pm2_all();
    $m = $all[pm2_name($serverId)] ?? null;
    json_out([
        'log'     => shell_available() ? pm2_logs($serverId) : 'Sunucuda exec() devre dışı; konsol kullanılamıyor.',
        'status'  => sync_status($srv, $all),
        'cpu'     => $m['cpu'] ?? 0,
        'memory'  => $m['memory'] ?? 0,
    ]);
}

// Tüm yazma işlemleri POST + CSRF ile
if (!is_post()) {
    redirect('servers.php');
}
csrf_check();

if (!$srv || !can_manage($srv, $user)) {
    flash('error', 'Sunucu bulunamadı veya yetkiniz yok.');
    redirect('servers.php');
}

$who  = ($user['role'] === 'admin' ? 'admin' : 'user') . '#' . $user['id'];
$back = match ((string)($_POST['back'] ?? 'detail')) {
    'list'  => 'servers.php',
    'admin' => 'admin_servers.php',
    default => 'server_detail.php?id=' . $serverId,
};
$detail = 'server_detail.php?id=' . $serverId;

switch ($do) {
    case 'start':
    case 'stop':
    case 'restart':
        [$ok, $msg] = server_lifecycle($srv, $do);
        add_log($serverId, $do . ' (' . $who . ')' . ($ok ? '' : ' - hata'));
        flash($ok ? 'success' : 'error', $msg);
        redirect($back);

    case 'delete':
        delete_server($srv);
        flash('success', 'Sunucu ve dosyaları silindi.');
        redirect(str_starts_with($back, 'server_detail') ? 'servers.php' : $back);

    case 'file_create':
        $name = safe_file_name((string)($_POST['file'] ?? ''));
        if ($name === null) {
            flash('error', 'Geçersiz dosya adı veya uzantı. İzinli uzantılar: .' . implode(', .', ALLOWED_EXT));
            redirect($detail);
        }
        $path = $srv['folder_path'] . '/' . $name;
        if (file_exists($path)) {
            flash('error', 'Bu isimde bir dosya zaten var.');
            redirect($detail . '&file=' . urlencode($name));
        }
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $seed = match ($ext) {
            'py'    => "# " . $name . "\n",
            'js', 'mjs', 'cjs' => "// " . $name . "\n",
            default => '',
        };
        if (file_put_contents($path, $seed) === false) {
            flash('error', 'Dosya oluşturulamadı (klasör yetkilerini kontrol edin).');
        } else {
            add_log($serverId, 'dosya oluşturuldu: ' . $name . ' (' . $who . ')');
            flash('success', "{$name} oluşturuldu.");
        }
        redirect($detail . '&file=' . urlencode($name));

    case 'file_save':
        $name = safe_file_name((string)($_POST['file'] ?? ''));
        if ($name === null || !is_file($srv['folder_path'] . '/' . $name)) {
            flash('error', 'Dosya bulunamadı.');
            redirect($detail);
        }
        $content = str_replace(["\r\n", "\r"], "\n", (string)($_POST['content'] ?? ''));
        if (strlen($content) > 2 * 1024 * 1024) {
            flash('error', 'Dosya 2 MB sınırını aşıyor.');
            redirect($detail . '&file=' . urlencode($name));
        }
        if (file_put_contents($srv['folder_path'] . '/' . $name, $content) === false) {
            flash('error', 'Dosya kaydedilemedi.');
        } else {
            add_log($serverId, 'dosya düzenlendi: ' . $name . ' (' . $who . ')');
            flash('success', "{$name} kaydedildi.");
        }
        redirect($detail . '&file=' . urlencode($name));

    case 'file_delete':
        $name = safe_file_name((string)($_POST['file'] ?? ''));
        if ($name === null || $name === $srv['main_file']) {
            flash('error', 'Ana dosya silinemez veya dosya geçersiz.');
            redirect($detail);
        }
        $path = $srv['folder_path'] . '/' . $name;
        if (is_file($path) && !is_link($path)) {
            @unlink($path);
            add_log($serverId, 'dosya silindi: ' . $name . ' (' . $who . ')');
            flash('success', "{$name} silindi.");
        }
        redirect($detail);

    default:
        flash('error', 'Geçersiz işlem.');
        redirect($back);
}
