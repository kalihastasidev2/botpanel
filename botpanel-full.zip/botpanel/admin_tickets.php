<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$admin = require_admin();
$ticketId = (int)($_GET['id'] ?? 0);
$filter = (string)($_GET['status'] ?? 'all');

if (is_post() && isset($_POST['quick_close'])) {
    csrf_check();
    db()->prepare("UPDATE tickets SET status = 'closed' WHERE id = ?")->execute([(int)$_POST['quick_close']]);
    flash('success', 'Talep kapatıldı.');
    redirect('admin_tickets.php');
}

if (is_post()) {
    csrf_check();
    $tid = (int)($_POST['ticket_id'] ?? 0);
    $message = trim((string)($_POST['message'] ?? ''));
    $close = isset($_POST['close']);

    $st = db()->prepare('SELECT id FROM tickets WHERE id = ?');
    $st->execute([$tid]);

    if (!$st->fetch()) {
        flash('error', 'Talep bulunamadı.');
    } elseif (mb_strlen($message) < 2 || mb_strlen($message) > 5000) {
        flash('error', 'Yanıt 2-5000 karakter olmalıdır.');
    } else {
        db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, is_admin, message) VALUES (?, ?, 1, ?)')
            ->execute([$tid, $admin['id'], $message]);
        db()->prepare('UPDATE tickets SET status = ? WHERE id = ?')
            ->execute([$close ? 'closed' : 'answered', $tid]);
        add_log(null, "destek #{$tid} yanıtlandı (admin#{$admin['id']})" . ($close ? ', kapatıldı' : ''));
        flash('success', $close ? 'Yanıt gönderildi ve talep kapatıldı.' : 'Yanıt gönderildi.');
    }
    redirect('admin_tickets.php?id=' . $tid);
}

render_layout_start('Destek Yönetimi', 'admin_tickets');

if ($ticketId > 0):
    $st = db()->prepare(
        'SELECT t.*, u.username FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ?'
    );
    $st->execute([$ticketId]);
    $ticket = $st->fetch();
    if (!$ticket):
        page_heading('Talep bulunamadı');
        echo '<a href="admin_tickets.php" class="text-brand-400">← Geri</a>';
    else:
        $rs = db()->prepare('SELECT * FROM ticket_replies WHERE ticket_id = ? ORDER BY id');
        $rs->execute([$ticketId]);
        $replies = $rs->fetchAll();
        ?>
        <div class="mb-6">
          <a href="admin_tickets.php" class="text-sm text-slate-500 hover:text-brand-300">← Tüm talepler</a>
          <div class="mt-2 flex flex-wrap items-center gap-3">
            <h1 class="text-2xl font-semibold text-white"><?= e($ticket['subject']) ?></h1>
            <?= ticket_status_badge($ticket['status']) ?>
            <span class="text-sm text-slate-400">Müşteri: <span class="text-white"><?= e($ticket['username']) ?></span></span>
          </div>
        </div>

        <?php render_thread($ticket, $replies, true); ?>

        <?php if ($ticket['status'] !== 'closed'): ?>
        <form method="post" class="<?= card_class() ?> mt-6 space-y-4">
          <?= csrf_field() ?>
          <input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
          <label class="block text-sm text-slate-400" for="reply">Yanıtınız</label>
          <textarea id="reply" name="message" rows="5" required maxlength="5000" class="<?= input_class() ?>"></textarea>
          <div class="flex flex-wrap items-center justify-between gap-4">
            <label class="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" name="close" class="h-4 w-4 accent-emerald-500"> Yanıtla ve kapat</label>
            <button class="<?= btn_class() ?>">Yanıtı Gönder</button>
          </div>
        </form>
        <?php else: ?>
          <p class="mt-6 rounded-xl bg-ink-900/70 p-4 text-center text-sm text-slate-500">Bu talep kapatılmıştır.</p>
        <?php endif; ?>
    <?php endif;
else:
    $where = ($filter === 'open' || $filter === 'answered' || $filter === 'closed') ? 'WHERE t.status = ?' : '';
    $sql = 'SELECT t.*, u.username FROM tickets t JOIN users u ON u.id = t.user_id ' . $where . ' ORDER BY FIELD(t.status,"open","answered","closed"), t.id DESC';
    $st = db()->prepare($sql);
    $st->execute($where ? [$filter] : []);
    $tickets = $st->fetchAll();
    page_heading('Destek Talepleri', 'Müşteri taleplerini yanıtlayın ve yönetin.');
    ?>
    <div class="mb-5 flex flex-wrap gap-2 text-sm">
      <?php foreach (['all' => 'Tümü', 'open' => 'Açık', 'answered' => 'Yanıtlandı', 'closed' => 'Kapalı'] as $k => $label): ?>
        <a href="?status=<?= $k ?>" class="rounded-lg px-3 py-1.5 ring-1 transition <?= $filter === $k ? 'bg-brand-500/15 text-brand-300 ring-brand-500/30' : 'text-slate-400 ring-ink-600 hover:bg-ink-700' ?>"><?= $label ?></a>
      <?php endforeach; ?>
    </div>

    <div class="<?= card_class() ?> overflow-hidden p-0">
      <?php if (!$tickets): ?>
        <p class="p-10 text-center text-sm text-slate-500">Bu filtrede talep yok.</p>
      <?php else: ?>
      <ul class="divide-y divide-ink-700">
        <?php foreach ($tickets as $t): ?>
        <li class="flex flex-wrap items-center justify-between gap-4 px-6 py-4 hover:bg-ink-700/20">
          <a href="admin_tickets.php?id=<?= (int)$t['id'] ?>" class="min-w-0 flex-1">
            <p class="truncate font-semibold text-white"><?= e($t['subject']) ?></p>
            <p class="text-xs text-slate-500">#<?= (int)$t['id'] ?> · <?= e($t['username']) ?> · <?= e($t['created_at']) ?></p>
          </a>
          <div class="flex items-center gap-3">
            <?= ticket_status_badge($t['status']) ?>
            <?php if ($t['status'] !== 'closed'): ?>
            <form method="post">
              <?= csrf_field() ?>
              <button name="quick_close" value="<?= (int)$t['id'] ?>" class="rounded-lg px-2.5 py-1 text-xs text-slate-400 ring-1 ring-ink-600 hover:bg-ink-700">Kapat</button>
            </form>
            <?php endif; ?>
          </div>
        </li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
    </div>
<?php endif;

render_layout_end();
