<?php
declare(strict_types=1);

function start_session_safe(): void
{
    if (session_status() !== PHP_SESSION_NONE) {
        return;
    }
    session_name('KTPANEL');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']) || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'),
    ]);
    session_start();
}

function e(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

function is_ajax_request(): bool
{
    return ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $token = $_POST['csrf'] ?? '';
    if (!is_string($token) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $token)) {
        flash('error', 'Oturum doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.');
        finish('index.php');
    }
}

/**
 * Bildirim ekler. AJAX isteğinde oturuma değil, istek sonunda JSON'a yazılır.
 */
function flash(string $type, string $msg): void
{
    if (is_ajax_request()) {
        $GLOBALS['ajax_flash'][] = ['type' => $type, 'msg' => $msg];
        return;
    }
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function get_flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $items;
}

/**
 * İşlemi bitirir. AJAX ise JSON döner (sayfa yenilenmez), değilse $back adresine yönlendirir.
 * $extra: JSON'a eklenecek ek alanlar (url = tarayıcı adres çubuğunu günceller, redirect = tam yönlendirme).
 */
function finish(string $back, array $extra = []): never
{
    if (!is_ajax_request()) {
        redirect($back);
    }
    $items = $GLOBALS['ajax_flash'] ?? [];
    $last  = $items ? end($items) : ['type' => 'success', 'msg' => 'Tamamlandı.'];
    $ok    = $last['type'] === 'success';
    json_out(['ok' => $ok, 'message' => $last['msg']] + $extra, $ok ? 200 : 422);
}

function json_out(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function money(float $amount): string
{
    return number_format($amount, 2, ',', '.') . ' ₺';
}
