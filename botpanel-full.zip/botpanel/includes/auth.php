<?php
declare(strict_types=1);

/**
 * Oturumdaki kullanıcıyı döndürür. Hesap askıya alınmışsa oturumu kapatır.
 */
function current_user(): ?array
{
    static $resolved = false;
    static $user = null;

    if ($resolved) {
        return $user;
    }
    $resolved = true;

    if (empty($_SESSION['uid'])) {
        return null;
    }

    $st = db()->prepare('SELECT id, username, role, balance, status, api_key, created_at FROM users WHERE id = ?');
    $st->execute([(int)$_SESSION['uid']]);
    $row = $st->fetch();

    if (!$row || $row['status'] !== 'active') {
        logout_user();
        return null;
    }
    $user = $row;
    return $user;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        flash('error', 'Devam etmek için giriş yapmalısınız.');
        redirect('login.php');
    }
    return $user;
}

function require_admin(): array
{
    $user = require_login();
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        exit('Bu sayfaya erişim yetkiniz yok.');
    }
    return $user;
}

function login_user(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    unset($_SESSION['csrf']);
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

/**
 * İşlem geçmişi kaydı. $serverId null olabilir (kullanıcı/admin işlemleri).
 */
function add_log(?int $serverId, string $action): void
{
    $st = db()->prepare('INSERT INTO logs (server_id, action) VALUES (?, ?)');
    $st->execute([$serverId, mb_substr($action, 0, 255)]);
}

/**
 * Bakiye tablosunu (ilk kullanımda) oluşturur. Kurulum yapılmış eski sistemlerde de çalışır.
 */
function ensure_balance_logs(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    db()->exec("CREATE TABLE IF NOT EXISTS balance_logs (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        balance_after DECIMAL(10,2) NOT NULL,
        reason VARCHAR(190) NOT NULL,
        actor VARCHAR(64) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_bl_user (user_id),
        CONSTRAINT fk_bl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $done = true;
}

/**
 * Bakiyeyi satırı kilitleyerek günceller ve geçmişe yazar. Yetersiz bakiyede RuntimeException atar.
 * Yeni bakiyeyi döndürür.
 */
function change_balance(int $userId, float $delta, string $reason, string $actor): float
{
    ensure_balance_logs();
    $pdo = db();
    $own = !$pdo->inTransaction();
    if ($own) {
        $pdo->beginTransaction();
    }
    try {
        $st = $pdo->prepare('SELECT balance FROM users WHERE id = ? FOR UPDATE');
        $st->execute([$userId]);
        $current = $st->fetchColumn();
        if ($current === false) {
            throw new RuntimeException('Kullanıcı bulunamadı.');
        }
        $new = round((float)$current + $delta, 2);
        if ($new < 0) {
            throw new RuntimeException('Yetersiz bakiye.');
        }
        $pdo->prepare('UPDATE users SET balance = ? WHERE id = ?')->execute([$new, $userId]);
        $pdo->prepare('INSERT INTO balance_logs (user_id, amount, balance_after, reason, actor) VALUES (?, ?, ?, ?, ?)')
            ->execute([$userId, $delta, $new, mb_substr($reason, 0, 190), mb_substr($actor, 0, 64)]);
        if ($own) {
            $pdo->commit();
        }
        return $new;
    } catch (Throwable $t) {
        if ($own && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $t;
    }
}
