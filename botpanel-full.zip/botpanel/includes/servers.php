<?php
declare(strict_types=1);

const ALLOWED_EXT = ['js', 'mjs', 'cjs', 'py', 'env', 'json', 'txt', 'md', 'yml', 'yaml', 'cfg', 'ini'];

function fetch_server(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM servers WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function can_manage(array $srv, array $user): bool
{
    return $user['role'] === 'admin' || (int)$srv['user_id'] === (int)$user['id'];
}

function count_user_servers(int $userId): int
{
    $st = db()->prepare('SELECT COUNT(*) FROM servers WHERE user_id = ?');
    $st->execute([$userId]);
    return (int)$st->fetchColumn();
}

/**
 * Benzersiz klasör adı: {uid}_{slug}_{rastgele}
 */
function server_folder_name(int $uid, string $name): string
{
    $slug = strtolower((string)preg_replace('/[^a-z0-9]+/i', '-', $name));
    $slug = trim($slug, '-');
    return $uid . '_' . ($slug !== '' ? $slug : 'bot') . '_' . bin2hex(random_bytes(4));
}

function server_set_status(int $id, string $status): void
{
    db()->prepare('UPDATE servers SET status = ? WHERE id = ?')->execute([$status, $id]);
}

function map_pm2_status(string $s): string
{
    return match ($s) {
        'online' => 'running',
        'errored' => 'error',
        default => 'stopped',
    };
}

/**
 * PM2'deki gerçek durumu alır ve veritabanını günceller.
 * PM2 kullanılamıyorsa veritabanındaki değeri döndürür.
 */
function sync_status(array $srv, ?array $all = null): string
{
    if ($all === null) {
        $all = pm2_all();
    }
    if ($all === null) {
        return $srv['status'];
    }
    $name = pm2_name((int)$srv['id']);
    $new = isset($all[$name]) ? map_pm2_status($all[$name]['status']) : 'stopped';
    if ($new !== $srv['status']) {
        server_set_status((int)$srv['id'], $new);
    }
    return $new;
}

/**
 * Başlat / durdur / yeniden başlat işlemleri. [başarılı mı, mesaj] döner.
 */
function server_lifecycle(array $srv, string $op): array
{
    $id = (int)$srv['id'];
    if (!shell_available()) {
        return [false, 'Sunucuda exec() devre dışı. PM2 kullanılamıyor.'];
    }

    switch ($op) {
        case 'start':
            [$ok, $msg] = pm2_start_bot($srv);
            break;
        case 'stop':
            [$ok, $msg] = pm2_control($id, 'stop');
            break;
        case 'restart':
            [$ok, $msg] = pm2_control($id, 'restart');
            if (!$ok) {
                [$ok, $msg] = pm2_start_bot($srv);
            }
            break;
        default:
            return [false, 'Geçersiz işlem.'];
    }

    $status = $ok ? ($op === 'stop' ? 'stopped' : 'running') : 'error';
    server_set_status($id, $status);

    return [$ok, $ok ? 'İşlem başarıyla tamamlandı.' : 'İşlem başarısız: ' . trim($msg)];
}

function rrmdir(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . '/' . $item;
        if (is_dir($path) && !is_link($path)) {
            rrmdir($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

/**
 * Sunucuyu tamamen siler: PM2 süreci, klasör ve veritabanı kaydı.
 */
function delete_server(array $srv): void
{
    $id = (int)$srv['id'];
    if (shell_available()) {
        pm2_control($id, 'delete');
    }

    $real = realpath($srv['folder_path']);
    $base = realpath(SERVERS_DIR);
    if ($real && $base && str_starts_with($real, $base . DIRECTORY_SEPARATOR)) {
        rrmdir($real);
    }

    db()->prepare('DELETE FROM servers WHERE id = ?')->execute([$id]);
    add_log(null, "sunucu #{$id} silindi ({$srv['bot_name']})");
}

/**
 * Klasör ve dosyalara 0777 yetkisi verir.
 * UYARI: Paylaşımlı ortamlarda güvenlik riski oluşturabilir.
 */
function chmod_recursive(string $path): void
{
    if (shell_available()) {
        sh('chmod -R 0777 ' . escapeshellarg($path), 60);
    }
    @chmod($path, 0777);
    if (is_dir($path)) {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $item) {
            @chmod($item->getPathname(), 0777);
        }
    }
}

function bot_templates(string $type, string $name): array
{
    $n = json_encode($name, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($type === 'nodejs') {
        $pkgName = strtolower((string)preg_replace('/[^a-z0-9-]+/i', '-', $name));
        $pkg = json_encode([
            'name'         => trim($pkgName, '-') ?: 'bot',
            'version'      => '1.0.0',
            'private'      => true,
            'main'         => 'index.js',
            'scripts'      => ['start' => 'node index.js'],
            'dependencies' => ['dotenv' => '^16.4.5'],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        $js = <<<JS
require('dotenv').config();

const NAME = {$n};
console.log('[' + NAME + '] Bot başlatıldı - ' + new Date().toLocaleString('tr-TR'));

setInterval(() => {
  console.log('[' + NAME + '] heartbeat ' + new Date().toLocaleTimeString('tr-TR'));
}, 10000);

JS;

        return [
            'index.js'     => $js,
            'package.json' => $pkg . "\n",
            '.env'         => "# Gizli anahtarlarınızı buraya yazın\n# TOKEN=\n",
        ];
    }

    $py = <<<PY
import time
from datetime import datetime

from dotenv import load_dotenv

load_dotenv()
NAME = {$n}
print(f"[{NAME}] Bot başlatıldı - {datetime.now():%d.%m.%Y %H:%M:%S}", flush=True)

while True:
    print(f"[{NAME}] heartbeat {datetime.now():%H:%M:%S}", flush=True)
    time.sleep(10)

PY;

    return [
        'bot.py'           => $py,
        'requirements.txt' => "python-dotenv==1.0.1\n",
        '.env'             => "# Gizli anahtarlarınızı buraya yazın\n# TOKEN=\n",
    ];
}

/**
 * Şablon dosyalarını oluşturur. Ana dosya adını döndürür.
 */
function create_bot_files(string $dir, string $type, string $name): string
{
    if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) {
        throw new RuntimeException('Bot klasörü oluşturulamadı.');
    }
    foreach (bot_templates($type, $name) as $file => $content) {
        if (file_put_contents($dir . '/' . $file, $content) === false) {
            throw new RuntimeException("Dosya yazılamadı: {$file}");
        }
    }
    chmod_recursive($dir);
    return $type === 'nodejs' ? 'index.js' : 'bot.py';
}

/**
 * Yalnızca üst düzey dosyaları listeler (dosya yöneticisi için).
 */
function list_bot_files(string $dir): array
{
    $files = [];
    if (!is_dir($dir)) {
        return $files;
    }
    foreach (scandir($dir) ?: [] as $f) {
        $p = $dir . '/' . $f;
        if ($f === '.' || $f === '..' || !is_file($p)) {
            continue;
        }
        $files[] = ['name' => $f, 'size' => filesize($p)];
    }
    usort($files, fn($a, $b) => strcmp($a['name'], $b['name']));
    return $files;
}

/**
 * Dosya adını doğrular: sadece güvenli karakterler ve izinli uzantılar.
 */
function safe_file_name(string $name): ?string
{
    $name = trim($name);
    if (!preg_match('/^[A-Za-z0-9._-]{1,100}$/', $name) || str_contains($name, '..')) {
        return null;
    }
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return in_array($ext, ALLOWED_EXT, true) ? $name : null;
}

function adjust_balance(int $userId, float $delta): void
{
    db()->prepare('UPDATE users SET balance = GREATEST(balance + ?, 0) WHERE id = ?')
        ->execute([$delta, $userId]);
}
