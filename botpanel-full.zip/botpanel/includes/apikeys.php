<?php
declare(strict_types=1);

/**
 * Anahtar yetkileri (kapsamlar). Anahtar oluşturulurken seçilir.
 */
const API_SCOPES = [
    'users.read'    => 'Müşterileri listele',
    'users.write'   => 'Müşteri oluştur, askıya al / kaldır',
    'balance.write' => 'Bakiye ekle / çıkar',
    'servers.read'  => 'Botları listele',
    'servers.write' => 'Bot oluştur, başlat, durdur, sil',
];

function ensure_api_keys(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    db()->exec("CREATE TABLE IF NOT EXISTS api_keys (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        owner_id INT UNSIGNED NOT NULL,
        name VARCHAR(80) NOT NULL,
        key_prefix VARCHAR(12) NOT NULL,
        key_hash CHAR(64) NOT NULL UNIQUE,
        scopes VARCHAR(255) NOT NULL,
        status ENUM('active','revoked') NOT NULL DEFAULT 'active',
        last_used_at TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_ak_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $done = true;
}

function find_active_user(int $id): ?array
{
    $st = db()->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

/**
 * Yeni anahtar üretir. Ham anahtar yalnızca bu fonksiyonun döndürdüğü değerde bulunur; veritabanında hash tutulur.
 */
function create_api_key(int $ownerId, string $name, array $scopes): string
{
    ensure_api_keys();
    $scopes = array_values(array_intersect(array_keys(API_SCOPES), $scopes));
    if (!$scopes) {
        throw new RuntimeException('En az bir yetki seçmelisiniz.');
    }
    $name = trim(mb_substr($name, 0, 80));
    if ($name === '') {
        throw new RuntimeException('Anahtara bir ad verin.');
    }
    $key = 'ktp_' . bin2hex(random_bytes(24));
    db()->prepare('INSERT INTO api_keys (owner_id, name, key_prefix, key_hash, scopes) VALUES (?, ?, ?, ?, ?)')
        ->execute([$ownerId, $name, substr($key, 0, 12), hash('sha256', $key), implode(',', $scopes)]);
    add_log(null, "API anahtarı oluşturuldu: {$name} (admin#{$ownerId})");
    return $key;
}

function revoke_api_key(int $keyId, int $ownerId): void
{
    ensure_api_keys();
    $st = db()->prepare("UPDATE api_keys SET status = 'revoked' WHERE id = ? AND owner_id = ?");
    $st->execute([$keyId, $ownerId]);
    if ($st->rowCount() === 0) {
        throw new RuntimeException('Anahtar bulunamadı.');
    }
    add_log(null, "API anahtarı iptal edildi (#{$keyId}, admin#{$ownerId})");
}

function list_api_keys(int $ownerId): array
{
    ensure_api_keys();
    $st = db()->prepare('SELECT id, name, key_prefix, scopes, status, last_used_at, created_at FROM api_keys WHERE owner_id = ? ORDER BY id DESC');
    $st->execute([$ownerId]);
    return $st->fetchAll();
}

/**
 * Bearer belirtecini doğrular.
 * Döner: ['user' => array, 'scopes' => array, 'key_id' => ?int] veya null.
 * - Yönetici anahtarı (ktp_...): sahibi aktif admin olmalı, kapsamlar anahtara göre.
 * - Eski müşteri anahtarı (profil sayfası): yalnızca kendi botlarını okuyabilir.
 */
function authenticate_api_key(string $token): ?array
{
    ensure_api_keys();
    $st = db()->prepare("SELECT id, owner_id, scopes FROM api_keys WHERE key_hash = ? AND status = 'active'");
    $st->execute([hash('sha256', $token)]);
    if ($row = $st->fetch()) {
        $user = find_active_user((int)$row['owner_id']);
        if (!$user || $user['role'] !== 'admin') {
            return null;
        }
        db()->prepare('UPDATE api_keys SET last_used_at = NOW() WHERE id = ?')->execute([$row['id']]);
        return ['user' => $user, 'scopes' => explode(',', $row['scopes']), 'key_id' => (int)$row['id']];
    }

    $st = db()->prepare("SELECT * FROM users WHERE api_key = ? AND status = 'active'");
    $st->execute([$token]);
    if ($user = $st->fetch()) {
        return ['user' => $user, 'scopes' => ['servers.read'], 'key_id' => null];
    }
    return null;
}

/**
 * Hedef kullanıcıyı user_id veya username ile bulur.
 */
function api_target_user(array $in): array
{
    if (!empty($in['user_id'])) {
        $st = db()->prepare('SELECT * FROM users WHERE id = ?');
        $st->execute([(int)$in['user_id']]);
    } elseif (!empty($in['username'])) {
        $st = db()->prepare('SELECT * FROM users WHERE username = ?');
        $st->execute([trim((string)$in['username'])]);
    } else {
        throw new RuntimeException('user_id veya username gerekli.');
    }
    return $st->fetch() ?: throw new RuntimeException('Kullanıcı bulunamadı.');
}

/**
 * Müşteri oluşturur. Şifre verilmezse üretilir ve yanıtta bir kez döner.
 */
function api_create_user(array $in, string $actor): array
{
    $username = trim((string)($in['username'] ?? ''));
    if (!preg_match('/^[A-Za-z0-9_]{3,32}$/', $username)) {
        throw new RuntimeException('Kullanıcı adı 3-32 karakter olmalı (harf, rakam, _).');
    }

    $password  = (string)($in['password'] ?? '');
    $generated = $password === '';
    if ($generated) {
        $password = bin2hex(random_bytes(6));
    }
    if (strlen($password) < 8) {
        throw new RuntimeException('Şifre en az 8 karakter olmalı.');
    }

    $balance = round((float)str_replace(',', '.', (string)($in['balance'] ?? 0)), 2);
    if ($balance < 0 || $balance > 100000) {
        throw new RuntimeException('Açılış bakiyesi 0 ile 100000 arasında olmalı.');
    }

    try {
        db()->prepare("INSERT INTO users (username, password, role, balance, status) VALUES (?, ?, 'user', 0, 'active')")
            ->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
    } catch (PDOException $ex) {
        if ($ex->getCode() === '23000') {
            throw new RuntimeException('Bu kullanıcı adı zaten var.');
        }
        throw $ex;
    }
    $id = (int)db()->lastInsertId();

    if ($balance > 0) {
        change_balance($id, $balance, 'Hesap açılış bakiyesi', $actor);
    }
    add_log(null, "müşteri oluşturuldu: {$username} (user#{$id}, {$actor})");

    return [
        'id'       => $id,
        'username' => $username,
        'balance'  => $balance,
        'password' => $generated ? $password : null,
    ];
}

/**
 * Bot oluşturur. charge=true ise BOT_CREATE_COST müşteri bakiyesinden düşer.
 * start=true ise oluşturulunca PM2 ile başlatır.
 */
function api_create_server(array $owner, array $in, string $actor): array
{
    $name = trim((string)($in['name'] ?? ''));
    if (!preg_match('/^[\p{L}\p{N} _-]{3,40}$/u', $name)) {
        throw new RuntimeException('Bot adı 3-40 karakter olmalı (harf, rakam, boşluk, - ve _).');
    }
    $type = (string)($in['type'] ?? '');
    if (!in_array($type, ['nodejs', 'python'], true)) {
        throw new RuntimeException('Tür nodejs veya python olmalı.');
    }
    $ram = (int)($in['ram'] ?? 256);
    $cpu = (int)($in['cpu'] ?? 100);
    if ($ram < 128 || $ram > 4096) {
        throw new RuntimeException('RAM 128 - 4096 MB arasında olmalı.');
    }
    if ($cpu < 10 || $cpu > 400) {
        throw new RuntimeException('CPU %10 - %400 arasında olmalı.');
    }

    $charge = !empty($in['charge']);
    if ($charge) {
        change_balance((int)$owner['id'], -BOT_CREATE_COST, 'Bot oluşturma ücreti: ' . $name, $actor);
    }

    if (!is_dir(SERVERS_DIR)) {
        mkdir(SERVERS_DIR, 0755, true);
    }
    $folder = SERVERS_DIR . '/' . server_folder_name((int)$owner['id'], $name);
    try {
        $main = create_bot_files($folder, $type, $name);
        db()->prepare(
            'INSERT INTO servers (user_id, bot_name, bot_type, folder_path, main_file, status, ram_limit, cpu_limit) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$owner['id'], $name, $type, $folder, $main, 'stopped', $ram, $cpu]);
    } catch (Throwable $t) {
        rrmdir($folder);
        if ($charge) {
            change_balance((int)$owner['id'], BOT_CREATE_COST, 'İade: bot oluşturulamadı', $actor);
        }
        throw new RuntimeException('Bot oluşturulamadı: ' . $t->getMessage());
    }

    $id  = (int)db()->lastInsertId();
    $srv = fetch_server($id);
    add_log($id, "bot oluşturuldu (user#{$owner['id']}, {$actor})");

    $result = ['id' => $id, 'user_id' => (int)$owner['id'], 'bot_name' => $name, 'bot_type' => $type, 'ram_limit' => $ram, 'cpu_limit' => $cpu, 'status' => 'stopped', 'message' => null];
    if (!empty($in['start'])) {
        [$ok, $msg] = server_lifecycle($srv, 'start');
        add_log($id, 'start (' . $actor . ')' . ($ok ? '' : ' - hata'));
        $result['status']  = $ok ? 'running' : 'error';
        $result['message'] = $msg;
    }
    return $result;
}
