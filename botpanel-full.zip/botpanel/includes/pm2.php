<?php
declare(strict_types=1);

/**
 * Shell fonksiyonlarının kullanılabilir olup olmadığını kontrol eder.
 */
function shell_available(): bool
{
    if (!function_exists('exec')) {
        return false;
    }
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array('exec', $disabled, true);
}

/**
 * Komutu zaman aşımı ile birlikte çalıştırır. [çıkış kodu, çıktı] döner.
 */
function sh(string $cmd, int $timeout = 60): array
{
    if (!shell_available()) {
        return [1, 'exec() devre dışı; shell komutu çalıştırılamadı.'];
    }
    $out = [];
    $code = 0;
    exec('timeout ' . (int)$timeout . ' sh -c ' . escapeshellarg($cmd) . ' 2>&1', $out, $code);
    return [$code, implode("\n", $out)];
}

function pm2_bin(): string
{
    static $bin = null;
    if ($bin === null) {
        [$code, $out] = sh('command -v pm2', 10);
        $bin = ($code === 0 && trim($out) !== '') ? trim($out) : 'pm2';
    }
    return $bin;
}

function pm2_run(string $args, int $timeout = 60): array
{
    $env = 'PM2_HOME=' . escapeshellarg(PM2_HOME) . ' HOME=' . escapeshellarg(dirname(PM2_HOME));
    return sh($env . ' ' . escapeshellarg(pm2_bin()) . ' ' . $args, $timeout);
}

/**
 * PM2 üzerindeki süreç adı. Port ve çakışma sorunu olmaması için sunucu ID'sine göre üretilir.
 */
function pm2_name(int $serverId): string
{
    return 'bot_' . $serverId;
}

/**
 * Tüm PM2 süreçlerini ad => [status, cpu, memory, restarts, uptime] olarak döndürür.
 * Shell kullanılamıyorsa null döner.
 */
function pm2_all(): ?array
{
    if (!shell_available()) {
        return null;
    }
    [$code, $out] = pm2_run('jlist', 20);
    if ($code !== 0) {
        return null;
    }
    $pos = strpos($out, '[');
    $list = $pos === false ? null : json_decode(substr($out, $pos), true);
    if (!is_array($list)) {
        return null;
    }

    $map = [];
    foreach ($list as $p) {
        $map[$p['name']] = [
            'status'   => $p['pm2_env']['status'] ?? 'unknown',
            'cpu'      => (float)($p['monit']['cpu'] ?? 0),
            'memory'   => (int)($p['monit']['memory'] ?? 0),
            'restarts' => (int)($p['pm2_env']['restart_time'] ?? 0),
            'uptime'   => (int)($p['pm2_env']['pm_uptime'] ?? 0),
        ];
    }
    return $map;
}

/**
 * Botu PM2 ile başlatır. Gerekliyse bağımlılıkları kurar.
 */
function pm2_start_bot(array $srv): array
{
    $dir  = $srv['folder_path'];
    $name = pm2_name((int)$srv['id']);
    $cd   = 'cd ' . escapeshellarg($dir) . ' && ';

    if ($srv['bot_type'] === 'nodejs') {
        if (is_file($dir . '/package.json') && !is_dir($dir . '/node_modules')) {
            [$code, $out] = sh($cd . 'npm install --omit=dev --no-audit --no-fund', 300);
            if ($code !== 0) {
                return [false, "npm install başarısız:\n" . $out];
            }
        }
    } elseif (is_file($dir . '/requirements.txt')) {
        [$code, $out] = sh(
            $cd . 'python3 -m pip install -q -r requirements.txt || python3 -m pip install -q --break-system-packages -r requirements.txt',
            300
        );
        if ($code !== 0) {
            return [false, "pip install başarısız:\n" . $out];
        }
    }

    // Aynı isimli eski süreç varsa temizle (hata olursa yoksay)
    pm2_run('delete ' . escapeshellarg($name), 20);

    $args = 'start ' . escapeshellarg($dir . '/' . $srv['main_file'])
        . ' --name ' . escapeshellarg($name)
        . ' --cwd ' . escapeshellarg($dir)
        . ' --max-memory-restart ' . (int)$srv['ram_limit'] . 'M';
    if ($srv['bot_type'] === 'python') {
        $args .= ' --interpreter python3';
    }

    [$code, $out] = pm2_run($args, 60);
    if ($code !== 0) {
        return [false, $out];
    }
    pm2_run('save', 20);
    return [true, $out];
}

/**
 * start / stop / restart / delete işlemleri.
 */
function pm2_control(int $serverId, string $op): array
{
    if (!in_array($op, ['stop', 'restart', 'delete'], true)) {
        return [false, 'Geçersiz PM2 işlemi'];
    }
    [$code, $out] = pm2_run($op . ' ' . escapeshellarg(pm2_name($serverId)), 30);
    if ($op === 'delete') {
        pm2_run('save', 20);
    }
    return [$code === 0, $out];
}

/**
 * Canlı log çıktısı (son N satır).
 */
function pm2_logs(int $serverId, int $lines = 200): string
{
    [, $out] = pm2_run('logs ' . escapeshellarg(pm2_name($serverId)) . ' --lines ' . $lines . ' --nostream', 20);
    return trim($out) === '' ? '(Henüz log çıktısı yok.)' : $out;
}
