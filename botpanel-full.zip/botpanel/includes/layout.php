<?php
declare(strict_types=1);

function render_head(string $title): void
{
    ?>
<!doctype html>
<html lang="tr" class="dark">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title><?= e($title) ?> · <?= e(APP_NAME) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: { 300: '#6ee7b7', 400: '#34d399', 500: '#10b981', 600: '#059669' },
            ink:   { 950: '#060913', 900: '#0b1020', 800: '#111a2e', 700: '#1e2a44', 600: '#2b3a5c' }
          },
          fontFamily: {
            sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
            mono: ['JetBrains Mono', 'ui-monospace', 'monospace']
          }
        }
      }
    };
  </script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
  <style>
    body { background: radial-gradient(1100px 500px at 0% -10%, rgba(16,185,129,.10), transparent 60%), #0b1020; }
    ::-webkit-scrollbar { width: 8px; height: 8px; }
    ::-webkit-scrollbar-thumb { background: #2b3a5c; border-radius: 8px; }
  </style>
  <script src="assets/app.js" defer></script>
</head>
<body class="min-h-screen font-sans text-slate-200 antialiased">
<?php
}

function render_flashes(): void
{
    foreach (get_flashes() as $f) {
        $cls = $f['type'] === 'error'
            ? 'border-red-500/40 bg-red-500/10 text-red-300'
            : 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300';
        echo '<div class="mb-6 rounded-xl border px-4 py-3 text-sm ' . $cls . '">' . e($f['msg']) . '</div>';
    }
}

/**
 * Giriş / kayıt gibi sidebar'sız sayfalar için başlangıç.
 */
function render_auth_start(string $title): void
{
    render_head($title);
    ?>
<div class="flex min-h-screen items-center justify-center p-4">
  <div class="w-full max-w-md">
    <div class="mb-8 text-center">
      <div class="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-emerald-700 text-lg font-bold text-ink-950 shadow-lg shadow-emerald-900/40">KT</div>
      <h1 class="text-2xl font-semibold text-white"><?= e(APP_NAME) ?></h1>
      <p class="text-sm text-slate-400">Bot Hosting Paneli</p>
    </div>
    <?php render_flashes(); ?>
    <div class="rounded-2xl border border-ink-700 bg-ink-800/70 p-8 shadow-2xl shadow-black/40 backdrop-blur">
<?php
}

function render_auth_end(): void
{
    echo '</div></div></div></body></html>';
}

/**
 * Oturum açmış kullanıcılar için ana yerleşim (sidebar + içerik).
 */
function render_layout_start(string $title, string $active = ''): void
{
    $u = current_user();
    $isAdmin = $u && $u['role'] === 'admin';

    $items = [
        ['index',         'Dashboard',       'index.php',           false],
        ['servers',       'Botlarım',        'servers.php',         false],
        ['create',        'Yeni Bot',        'create_server.php',   false],
        ['support',       'Destek Talepleri','support.php',         false],
        ['profile',       'Profil & API',    'profile.php',         false],
        ['admin',         'Yönetim Paneli',  'admin.php',           true],
        ['admin_users',   'Müşteriler',      'admin_users.php',     true],
        ['admin_servers', 'Tüm Sunucular',   'admin_servers.php',   true],
        ['admin_tickets', 'Destek Yönetimi', 'admin_tickets.php',   true],
        ['admin_api',     'API Yönetimi',    'admin_api.php',       true],
    ];

    $linkClass = static function (string $key) use ($active): string {
        return $active === $key
            ? 'bg-brand-500/15 text-brand-300 ring-1 ring-brand-500/30'
            : 'text-slate-400 hover:bg-ink-800 hover:text-white';
    };

    render_head($title);
    ?>
<div class="flex min-h-screen">
  <aside class="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-ink-700 bg-ink-950/70 p-5 backdrop-blur md:flex">
    <a href="index.php" class="mb-8 flex items-center gap-3">
      <span class="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-emerald-700 font-bold text-ink-950">KT</span>
      <span>
        <span class="block text-sm font-semibold text-white"><?= e(APP_NAME) ?></span>
        <span class="text-xs text-slate-500">Bot Hosting Paneli</span>
      </span>
    </a>
    <nav class="flex-1 space-y-1 overflow-y-auto">
      <?php foreach ($items as [$key, $label, $href, $adminOnly]): ?>
        <?php if ($adminOnly && !$isAdmin) { continue; } ?>
        <?php if ($adminOnly && $key === 'admin'): ?>
          <p class="px-3 pb-2 pt-6 text-[11px] font-semibold uppercase tracking-wider text-slate-500">Yönetim</p>
        <?php endif; ?>
        <a href="<?= e($href) ?>" class="block rounded-xl px-3 py-2.5 text-sm font-medium transition <?= $linkClass($key) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <?php if ($u): ?>
    <div class="mt-6 rounded-xl border border-ink-700 bg-ink-800/60 p-4">
      <p class="text-xs text-slate-500">Oturum</p>
      <p class="truncate font-semibold text-white"><?= e($u['username']) ?></p>
      <p class="text-xs text-slate-400">Bakiye: <span class="text-brand-300"><?= e(money((float)$u['balance'])) ?></span></p>
      <a href="logout.php" class="mt-3 block rounded-lg bg-red-500/10 px-3 py-2 text-center text-xs font-semibold text-red-300 ring-1 ring-red-500/30 hover:bg-red-500/20">Çıkış Yap</a>
    </div>
    <?php endif; ?>
  </aside>

  <div class="flex min-w-0 flex-1 flex-col">
    <header class="sticky top-0 z-10 border-b border-ink-700 bg-ink-950/80 px-4 py-3 backdrop-blur md:hidden">
      <div class="mb-2 flex items-center justify-between">
        <span class="font-semibold text-white"><?= e(APP_NAME) ?></span>
        <a href="logout.php" class="text-xs text-red-300">Çıkış</a>
      </div>
      <nav class="flex gap-2 overflow-x-auto pb-1 text-xs">
        <?php foreach ($items as [$key, $label, $href, $adminOnly]): ?>
          <?php if ($adminOnly && !$isAdmin) { continue; } ?>
          <a href="<?= e($href) ?>" class="shrink-0 rounded-lg px-3 py-1.5 ring-1 ring-ink-700 <?= $linkClass($key) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
      </nav>
    </header>

    <main class="mx-auto w-full max-w-7xl flex-1 p-4 md:p-8">
      <?php render_flashes(); ?>
<?php
}

function render_layout_end(): void
{
    ?>
    </main>
    <footer class="border-t border-ink-700 px-8 py-4 text-center text-xs text-slate-600">
      <?= e(APP_NAME) ?> · PM2 tabanlı bot yönetimi
    </footer>
  </div>
</div>
<div id="toasts" class="pointer-events-none fixed bottom-4 right-4 z-50 flex w-[22rem] max-w-[calc(100vw-2rem)] flex-col gap-2"></div>
</body>
</html>
<?php
}

function page_heading(string $title, string $subtitle = ''): void
{
    echo '<div class="mb-8"><h1 class="text-2xl font-semibold text-white">' . e($title) . '</h1>';
    if ($subtitle !== '') {
        echo '<p class="mt-1 text-sm text-slate-400">' . e($subtitle) . '</p>';
    }
    echo '</div>';
}

function card_class(): string
{
    return 'rounded-2xl border border-ink-700 bg-ink-800/60 p-6 shadow-xl shadow-black/20';
}

function input_class(): string
{
    return 'w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-brand-500 focus:ring-2 focus:ring-brand-500/30';
}

function btn_class(string $variant = 'primary'): string
{
    $base = 'inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:opacity-50';
    return $base . ' ' . match ($variant) {
        'danger'  => 'bg-red-500/15 text-red-300 ring-1 ring-red-500/30 hover:bg-red-500/25',
        'ghost'   => 'text-slate-300 ring-1 ring-ink-600 hover:bg-ink-700',
        default   => 'bg-brand-500 text-ink-950 shadow-lg shadow-emerald-900/30 hover:bg-brand-400',
    };
}

function status_badge(string $status): string
{
    [$cls, $label] = match ($status) {
        'running' => ['bg-emerald-500/15 text-emerald-300 ring-emerald-500/30', 'Çalışıyor'],
        'error'   => ['bg-red-500/15 text-red-300 ring-red-500/30', 'Hata'],
        default   => ['bg-slate-500/15 text-slate-300 ring-slate-500/30', 'Durdu'],
    };
    return '<span class="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ring-1 ' . $cls . '">'
        . '<span class="h-1.5 w-1.5 rounded-full bg-current"></span>' . $label . '</span>';
}

function type_badge(string $type): string
{
    $cls = $type === 'nodejs'
        ? 'bg-lime-500/15 text-lime-300 ring-lime-500/30'
        : 'bg-sky-500/15 text-sky-300 ring-sky-500/30';
    return '<span class="inline-flex rounded-md px-2 py-0.5 text-xs font-medium ring-1 ' . $cls . '">'
        . ($type === 'nodejs' ? 'Node.js' : 'Python') . '</span>';
}

function ticket_status_badge(string $status): string
{
    [$cls, $label] = match ($status) {
        'answered' => ['bg-sky-500/15 text-sky-300 ring-sky-500/30', 'Yanıtlandı'],
        'closed'   => ['bg-slate-500/15 text-slate-400 ring-slate-500/30', 'Kapalı'],
        default    => ['bg-amber-500/15 text-amber-300 ring-amber-500/30', 'Açık'],
    };
    return '<span class="inline-flex rounded-full px-2.5 py-1 text-xs font-medium ring-1 ' . $cls . '">' . $label . '</span>';
}

/**
 * Sunucu üzerinde hızlı işlem butonu (action.php'ye POST).
 */
function action_button(int $serverId, string $op, string $label, string $variant = 'info', string $back = 'detail', ?string $confirm = null): string
{
    $cls = match ($variant) {
        'danger'  => 'bg-red-500/15 text-red-300 ring-red-500/30 hover:bg-red-500/25',
        'success' => 'bg-emerald-500/15 text-emerald-300 ring-emerald-500/30 hover:bg-emerald-500/25',
        'warn'    => 'bg-amber-500/15 text-amber-300 ring-amber-500/30 hover:bg-amber-500/25',
        default   => 'bg-sky-500/15 text-sky-300 ring-sky-500/30 hover:bg-sky-500/25',
    };
    $confirmAttr = $confirm !== null ? ' data-confirm="' . e($confirm) . '"' : '';

    return '<form method="post" action="action.php" class="inline" data-ajax' . $confirmAttr . '>'
        . csrf_field()
        . '<input type="hidden" name="server_id" value="' . $serverId . '">'
        . '<input type="hidden" name="do" value="' . e($op) . '">'
        . '<input type="hidden" name="back" value="' . e($back) . '">'
        . '<button class="inline-flex items-center rounded-lg px-3 py-1.5 text-xs font-semibold ring-1 transition ' . $cls . '">' . e($label) . '</button>'
        . '</form>';
}

/**
 * Destek talebi konuşma görünümü.
 */
function render_thread(array $ticket, array $replies, bool $viewerIsAdmin): void
{
    echo '<div class="space-y-4">';
    echo '<div class="rounded-2xl border border-ink-700 bg-ink-900/70 p-5">';
    echo '<div class="mb-2 flex items-center justify-between text-xs text-slate-500"><span>Talep sahibi (#' . (int)$ticket['user_id'] . ')</span><span>' . e($ticket['created_at']) . '</span></div>';
    echo '<p class="whitespace-pre-wrap text-sm leading-relaxed text-slate-200">' . e($ticket['message']) . '</p>';
    echo '</div>';

    foreach ($replies as $r) {
        $mine = $viewerIsAdmin ? (bool)$r['is_admin'] : !$r['is_admin'];
        $ring = $r['is_admin'] ? 'border-brand-500/30 bg-brand-500/5' : 'border-ink-700 bg-ink-900/70';
        $who = $r['is_admin'] ? 'Destek Ekibi' : 'Müşteri';
        $align = $mine ? 'ml-8 md:ml-16' : 'mr-8 md:mr-16';
        echo '<div class="rounded-2xl border p-5 ' . $ring . ' ' . $align . '">';
        echo '<div class="mb-2 flex items-center justify-between text-xs text-slate-500"><span class="font-medium text-slate-300">' . e($who) . '</span><span>' . e($r['created_at']) . '</span></div>';
        echo '<p class="whitespace-pre-wrap text-sm leading-relaxed text-slate-200">' . e($r['message']) . '</p>';
        echo '</div>';
    }
    echo '</div>';
}
