<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$admin = require_admin();
ensure_balance_logs();
ensure_api_keys();

/* ---------- İşlemler (AJAX destekli) ---------- */
if (is_post()) {
    csrf_check();
    $act = (string)($_POST['act'] ?? '');

    try {
        switch ($act) {
            case 'key_create':
                $scopes = array_map('strval', (array)($_POST['scopes'] ?? []));
                $key = create_api_key((int)$admin['id'], (string)($_POST['name'] ?? ''), $scopes);
                $_SESSION['new_api_key'] = $key;
                flash('success', 'API anahtarı oluşturuldu. Anahtarı şimdi kopyalayın, bir daha gösterilmeyecek.');
                break;

            case 'key_revoke':
                revoke_api_key((int)($_POST['key_id'] ?? 0), (int)$admin['id']);
                flash('success', 'Anahtar iptal edildi.');
                break;

            case 'user_create':
                $r = api_create_user([
                    'username' => $_POST['username'] ?? '',
                    'password' => $_POST['password'] ?? '',
                    'balance'  => $_POST['balance'] ?? 0,
                ], 'admin#' . $admin['id']);
                $msg = "Hesap oluşturuldu: {$r['username']}";
                if ($r['password'] !== null) {
                    $msg .= " · Geçici şifre: {$r['password']}";
                }
                flash('success', $msg);
                break;

            case 'balance':
                $target = api_target_user(['username' => $_POST['username'] ?? '']);
                $amount = round((float)str_replace(',', '.', (string)($_POST['amount'] ?? '0')), 2);
                if ($amount <= 0 || $amount > 100000) {
                    throw new RuntimeException('Tutar 0 ile 100000 arasında olmalı.');
                }
                $sign = ($_POST['op'] ?? 'add') === 'sub' ? -1 : 1;
                $note = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 190) ?: 'Panel bakiye işlemi';
                $new  = change_balance((int)$target['id'], $sign * $amount, $note, 'admin#' . $admin['id']);
                add_log(null, sprintf('bakiye %s%.2f (user#%d, admin#%d)', $sign > 0 ? '+' : '-', $amount, $target['id'], $admin['id']));
                flash('success', "{$target['username']} bakiyesi güncellendi. Yeni bakiye: " . money($new));
                break;

            default:
                flash('error', 'Geçersiz işlem.');
        }
    } catch (RuntimeException $ex) {
        flash('error', $ex->getMessage());
    } catch (Throwable $t) {
        flash('error', 'Beklenmeyen bir hata oluştu.');
    }
    finish('admin_api.php');
}

/* ---------- Görünüm verileri ---------- */
$scheme = (!empty($_SERVER['HTTPS']) || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')) ? 'https' : 'http';
$base   = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');

$newKey = $_SESSION['new_api_key'] ?? null;
unset($_SESSION['new_api_key']);

$keys      = list_api_keys((int)$admin['id']);
$usernames = db()->query("SELECT username FROM users WHERE status = 'active' ORDER BY username")->fetchAll(PDO::FETCH_COLUMN);
$logs      = db()->query('SELECT b.*, u.username FROM balance_logs b JOIN users u ON u.id = b.user_id ORDER BY b.id DESC LIMIT 50')->fetchAll();

$endpoints = [
    ['GET',  'me',            '—',               'Kendi bilgileriniz ve yetkileriniz'],
    ['GET',  'users',         'users.read',      'Müşteri listesi'],
    ['POST', 'user.create',   'users.write',     'Müşteri oluştur: username, password?, balance?'],
    ['POST', 'user.suspend',  'users.write',     'Askıya al / kaldır: user_id|username, status'],
    ['POST', 'balance',       'balance.write',   'Bakiye: user_id|username, amount, op (add|sub), note?'],
    ['GET',  'servers',       'servers.read',    'Bot listesi (?user_id= ile filtre)'],
    ['POST', 'server.create', 'servers.write',   'Bot oluştur: user_id|username, name, type, ram?, cpu?, start?, charge?'],
    ['POST', 'server.action', 'servers.write',   'Bot işlemi: server_id, do (start|stop|restart|delete)'],
];

render_layout_start('API Yönetimi', 'admin_api');
page_heading('API Yönetimi', 'Anahtar oluşturun, her anahtara yetki verin, bakiye ve bot işlemlerini dışarıdan yönetin.');
?>

<!-- Anahtarlar -->
<section id="api-keys" data-swap class="<?= card_class() ?>">
  <div class="flex flex-wrap items-center justify-between gap-3">
    <div>
      <h2 class="text-lg font-semibold text-white">API anahtarları</h2>
      <p class="mt-1 text-sm text-slate-400">Her anahtarın yalnızca seçtiğiniz yetkileri vardır. Anahtarı kimseyle paylaşmayın.</p>
    </div>
  </div>

  <?php if ($newKey): ?>
  <div class="mt-5 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4">
    <p class="text-sm font-semibold text-amber-200">Yeni anahtarınız (sadece bir kez gösterilir):</p>
    <div class="mt-2 flex flex-wrap items-center gap-3">
      <code id="new-key" class="break-all font-mono text-sm text-emerald-300"><?= e($newKey) ?></code>
      <button type="button" class="<?= btn_class('ghost') ?> !py-1.5 text-xs" onclick="navigator.clipboard.writeText(document.getElementById('new-key').textContent).then(()=>this.textContent='Kopyalandı ✓')">Kopyala</button>
    </div>
  </div>
  <?php endif; ?>

  <div class="mt-6 overflow-x-auto rounded-xl border border-ink-700">
    <table class="w-full min-w-[720px] text-left text-sm">
      <thead class="bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500">
        <tr><th class="px-4 py-3 font-medium">Ad</th><th class="px-4 py-3 font-medium">Anahtar</th><th class="px-4 py-3 font-medium">Yetkiler</th><th class="px-4 py-3 font-medium">Son kullanım</th><th class="px-4 py-3 font-medium">Durum</th><th class="px-4 py-3 text-right font-medium"></th></tr>
      </thead>
      <tbody class="divide-y divide-ink-700">
      <?php foreach ($keys as $k): ?>
        <tr>
          <td class="px-4 py-3 font-semibold text-white"><?= e($k['name']) ?></td>
          <td class="px-4 py-3 font-mono text-xs text-slate-400"><?= e($k['key_prefix']) ?>••••</td>
          <td class="px-4 py-3">
            <div class="flex flex-wrap gap-1">
              <?php foreach (explode(',', $k['scopes']) as $sc): ?>
                <span class="rounded-md bg-sky-500/10 px-1.5 py-0.5 font-mono text-[11px] text-sky-300 ring-1 ring-sky-500/20"><?= e($sc) ?></span>
              <?php endforeach; ?>
            </div>
          </td>
          <td class="px-4 py-3 text-xs text-slate-500"><?= $k['last_used_at'] ? e($k['last_used_at']) : 'Hiç' ?></td>
          <td class="px-4 py-3"><?= $k['status'] === 'active'
              ? '<span class="rounded-full bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-300">Aktif</span>'
              : '<span class="rounded-full bg-red-500/15 px-2 py-0.5 text-xs text-red-300">İptal</span>' ?></td>
          <td class="px-4 py-3 text-right">
            <?php if ($k['status'] === 'active'): ?>
            <form method="post" data-ajax data-confirm="Bu anahtar iptal edilecek. Emin misiniz?">
              <?= csrf_field() ?>
              <input type="hidden" name="act" value="key_revoke">
              <input type="hidden" name="key_id" value="<?= (int)$k['id'] ?>">
              <button class="rounded-lg bg-red-500/15 px-2.5 py-1 text-xs font-semibold text-red-300 ring-1 ring-red-500/30">İptal Et</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$keys): ?>
        <tr><td colspan="6" class="px-4 py-8 text-center text-slate-500">Henüz anahtar yok. Aşağıdan oluşturun.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

  <form method="post" data-ajax data-reset class="mt-6 space-y-4 rounded-xl bg-ink-900/70 p-5">
    <?= csrf_field() ?>
    <input type="hidden" name="act" value="key_create">
    <p class="text-sm font-semibold text-white">Yeni anahtar</p>
    <input name="name" required maxlength="80" placeholder="Örn: Ödeme sistemi, Discord botu" class="<?= input_class() ?>">
    <div class="grid gap-2 sm:grid-cols-2">
      <?php foreach (API_SCOPES as $scope => $label): ?>
      <label class="flex items-start gap-3 rounded-lg bg-ink-950/60 px-3 py-2.5 text-sm">
        <input type="checkbox" name="scopes[]" value="<?= e($scope) ?>" class="mt-0.5 h-4 w-4 accent-emerald-500">
        <span><span class="block font-mono text-xs text-sky-300"><?= e($scope) ?></span><span class="text-slate-400"><?= e($label) ?></span></span>
      </label>
      <?php endforeach; ?>
    </div>
    <div class="flex justify-end"><button class="<?= btn_class() ?>" data-busy="Oluşturuluyor…">Anahtar Oluştur</button></div>
  </form>
</section>

<!-- Hızlı işlemler -->
<div class="mt-6 grid gap-6 xl:grid-cols-2">
  <form method="post" data-ajax data-reset class="<?= card_class() ?> space-y-4">
    <h2 class="text-lg font-semibold text-white">Müşteri oluştur</h2>
    <?= csrf_field() ?>
    <input type="hidden" name="act" value="user_create">
    <input name="username" required placeholder="Kullanıcı adı" class="<?= input_class() ?>">
    <div class="grid grid-cols-2 gap-3">
      <input name="password" placeholder="Şifre (boşsa üretilir)" class="<?= input_class() ?>">
      <input name="balance" inputmode="decimal" value="0" placeholder="Açılış bakiyesi" class="<?= input_class() ?>">
    </div>
    <button class="<?= btn_class() ?> w-full" data-busy="Oluşturuluyor…">Müşteri Oluştur</button>
  </form>

  <form method="post" data-ajax data-reset class="<?= card_class() ?> space-y-4">
    <h2 class="text-lg font-semibold text-white">Bakiye işlemi</h2>
    <?= csrf_field() ?>
    <input type="hidden" name="act" value="balance">
    <input name="username" list="user-list" required autocomplete="off" placeholder="Kullanıcı adı" class="<?= input_class() ?>">
    <datalist id="user-list"><?php foreach ($usernames as $u): ?><option value="<?= e($u) ?>"><?php endforeach; ?></datalist>
    <div class="grid grid-cols-2 gap-3">
      <input name="amount" inputmode="decimal" required placeholder="Tutar" class="<?= input_class() ?>">
      <select name="op" class="<?= input_class() ?>"><option value="add">Ekle</option><option value="sub">Çıkar</option></select>
    </div>
    <input name="note" maxlength="190" placeholder="Not (ödeme, iade...)" class="<?= input_class() ?>">
    <button class="<?= btn_class() ?> w-full" data-busy="İşleniyor…">Uygula</button>
  </form>
</div>

<!-- Belgeler -->
<section class="<?= card_class() ?> mt-6">
  <h2 class="text-lg font-semibold text-white">Uç noktalar</h2>
  <p class="mt-1 text-sm text-slate-400">Adres: <code class="font-mono text-slate-300"><?= e($base) ?>/api.php?action=UC_NOKTA</code> · Başlık: <code class="font-mono text-slate-300">Authorization: Bearer ANAHTAR</code></p>
  <div class="mt-4 overflow-x-auto rounded-xl border border-ink-700">
    <table class="w-full min-w-[640px] text-left text-sm">
      <thead class="bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500"><tr><th class="px-4 py-2.5 font-medium">Metot</th><th class="px-4 py-2.5 font-medium">action</th><th class="px-4 py-2.5 font-medium">Yetki</th><th class="px-4 py-2.5 font-medium">Açıklama</th></tr></thead>
      <tbody class="divide-y divide-ink-700">
      <?php foreach ($endpoints as [$method, $act, $scope, $desc]): ?>
        <tr><td class="px-4 py-2.5 font-mono text-xs text-amber-300"><?= $method ?></td><td class="px-4 py-2.5 font-mono text-xs text-white"><?= e($act) ?></td><td class="px-4 py-2.5 font-mono text-xs text-sky-300"><?= e($scope) ?></td><td class="px-4 py-2.5 text-slate-400"><?= e($desc) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

<pre class="mt-5 overflow-x-auto rounded-xl border border-ink-700 bg-black/50 p-4 font-mono text-xs leading-relaxed text-slate-300"># Müşteri oluştur (şifre verilmezse üretilir ve yanıtta döner)
curl -X POST "<?= e($base) ?>/api.php?action=user.create" \
  -H "Authorization: Bearer ktp_ANAHTARINIZ" -H "Content-Type: application/json" \
  -d '{"username":"musteri1","balance":50}'

# Bakiye ekle
curl -X POST "<?= e($base) ?>/api.php?action=balance" \
  -H "Authorization: Bearer ktp_ANAHTARINIZ" -H "Content-Type: application/json" \
  -d '{"username":"musteri1","amount":100,"op":"add","note":"Ödeme"}'

# Müşteriye 2 GB RAM'li Python botu oluştur, başlat ve bakiyeden 25 ₺ düş
curl -X POST "<?= e($base) ?>/api.php?action=server.create" \
  -H "Authorization: Bearer ktp_ANAHTARINIZ" -H "Content-Type: application/json" \
  -d '{"username":"musteri1","name":"Duyuru Botu","type":"python","ram":2048,"cpu":100,"start":true,"charge":true}'

# Bot durdur
curl -X POST "<?= e($base) ?>/api.php?action=server.action" \
  -H "Authorization: Bearer ktp_ANAHTARINIZ" -H "Content-Type: application/json" \
  -d '{"server_id":5,"do":"stop"}'</pre>
</section>

<!-- Bakiye geçmişi -->
<section id="balance-logs" data-swap class="<?= card_class() ?> mt-6 overflow-hidden p-0">
  <div class="border-b border-ink-700 px-6 py-4">
    <h2 class="font-semibold text-white">Bakiye geçmişi</h2>
    <p class="text-xs text-slate-500">Son 50 işlem (panel ve API)</p>
  </div>
  <div class="overflow-x-auto">
    <table class="w-full min-w-[680px] text-left text-sm">
      <thead class="bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500">
        <tr><th class="px-6 py-3 font-medium">Zaman</th><th class="px-6 py-3 font-medium">Kullanıcı</th><th class="px-6 py-3 font-medium">Tutar</th><th class="px-6 py-3 font-medium">Yeni bakiye</th><th class="px-6 py-3 font-medium">Not</th><th class="px-6 py-3 font-medium">Kaynak</th></tr>
      </thead>
      <tbody class="divide-y divide-ink-700">
      <?php foreach ($logs as $l): $amt = (float)$l['amount']; ?>
        <tr class="hover:bg-ink-700/20">
          <td class="px-6 py-3 text-slate-500"><?= e($l['created_at']) ?></td>
          <td class="px-6 py-3 text-white"><?= e($l['username']) ?></td>
          <td class="px-6 py-3 font-semibold <?= $amt >= 0 ? 'text-emerald-300' : 'text-red-300' ?>"><?= ($amt >= 0 ? '+' : '') . e(money($amt)) ?></td>
          <td class="px-6 py-3 text-slate-300"><?= e(money((float)$l['balance_after'])) ?></td>
          <td class="px-6 py-3 text-slate-400"><?= e($l['reason']) ?></td>
          <td class="px-6 py-3 font-mono text-xs text-slate-500"><?= e($l['actor']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$logs): ?>
        <tr><td colspan="6" class="px-6 py-8 text-center text-slate-500">Henüz bakiye işlemi yok.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php render_layout_end();
