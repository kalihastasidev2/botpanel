<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();

if (is_post()) {
    csrf_check();
    $form = (string)($_POST['form'] ?? '');

    if ($form === 'password') {
        $current = (string)($_POST['current'] ?? '');
        $new     = (string)($_POST['new'] ?? '');
        $confirm = (string)($_POST['confirm'] ?? '');

        $st = db()->prepare('SELECT password FROM users WHERE id = ?');
        $st->execute([$user['id']]);
        $hash = (string)$st->fetchColumn();

        if (!password_verify($current, $hash)) {
            flash('error', 'Mevcut şifreniz hatalı.');
        } elseif (strlen($new) < 8) {
            flash('error', 'Yeni şifre en az 8 karakter olmalı.');
        } elseif ($new !== $confirm) {
            flash('error', 'Yeni şifreler eşleşmiyor.');
        } else {
            db()->prepare('UPDATE users SET password = ? WHERE id = ?')
                ->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            add_log(null, 'şifre değiştirildi (user#' . $user['id'] . ')');
            flash('success', 'Şifreniz güncellendi.');
        }
    }

    if ($form === 'apikey') {
        $key = bin2hex(random_bytes(32));
        db()->prepare('UPDATE users SET api_key = ? WHERE id = ?')->execute([$key, $user['id']]);
        add_log(null, 'API anahtarı yenilendi (user#' . $user['id'] . ')');
        flash('success', 'Yeni API anahtarı oluşturuldu. Eski anahtar artık geçersiz.');
    }

    redirect('profile.php');
}

$st = db()->prepare('SELECT api_key FROM users WHERE id = ?');
$st->execute([$user['id']]);
$apiKey = (string)$st->fetchColumn();

$origin = (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');

render_layout_start('Profil & API', 'profile');
page_heading('Profil & API Anahtarı', 'Hesap güvenliğiniz ve harici entegrasyonlarınız.');
?>
<div class="grid gap-6 xl:grid-cols-2">
  <div class="<?= card_class() ?>">
    <h2 class="text-lg font-semibold text-white">Hesap bilgileri</h2>
    <dl class="mt-5 space-y-3 text-sm">
      <div class="flex justify-between rounded-xl bg-ink-900/70 px-4 py-3"><dt class="text-slate-400">Kullanıcı adı</dt><dd class="font-semibold text-white"><?= e($user['username']) ?></dd></div>
      <div class="flex justify-between rounded-xl bg-ink-900/70 px-4 py-3"><dt class="text-slate-400">Rol</dt><dd class="text-white"><?= $user['role'] === 'admin' ? 'Yönetici' : 'Müşteri' ?></dd></div>
      <div class="flex justify-between rounded-xl bg-ink-900/70 px-4 py-3"><dt class="text-slate-400">Bakiye</dt><dd class="font-semibold text-brand-300"><?= e(money((float)$user['balance'])) ?></dd></div>
      <div class="flex justify-between rounded-xl bg-ink-900/70 px-4 py-3"><dt class="text-slate-400">Kayıt tarihi</dt><dd class="text-slate-300"><?= e($user['created_at']) ?></dd></div>
    </dl>

    <h3 class="mt-8 text-base font-semibold text-white">Şifre değiştir</h3>
    <form method="post" class="mt-4 space-y-4">
      <?= csrf_field() ?>
      <input type="hidden" name="form" value="password">
      <input type="password" name="current" required placeholder="Mevcut şifre" autocomplete="current-password" class="<?= input_class() ?>">
      <input type="password" name="new" required minlength="8" placeholder="Yeni şifre" autocomplete="new-password" class="<?= input_class() ?>">
      <input type="password" name="confirm" required minlength="8" placeholder="Yeni şifre (tekrar)" autocomplete="new-password" class="<?= input_class() ?>">
      <button class="<?= btn_class() ?>">Şifreyi Güncelle</button>
    </form>
  </div>

  <div class="<?= card_class() ?>">
    <h2 class="text-lg font-semibold text-white">API Anahtarı</h2>
    <p class="mt-1 text-sm text-slate-400">Botlarınızın durumunu harici sistemlerden sorgulamak için kullanın. Anahtarı kimseyle paylaşmayın.</p>

    <div class="mt-5 rounded-xl border border-ink-600 bg-ink-950 p-4">
      <?php if ($apiKey): ?>
        <code class="block break-all font-mono text-sm text-emerald-300"><?= e($apiKey) ?></code>
      <?php else: ?>
        <p class="text-sm text-slate-500">Henüz bir API anahtarınız yok.</p>
      <?php endif; ?>
    </div>

    <form method="post" class="mt-4" onsubmit="return confirm('Mevcut anahtar geçersiz olacak. Devam edilsin mi?')">
      <?= csrf_field() ?>
      <input type="hidden" name="form" value="apikey">
      <button class="<?= btn_class('ghost') ?>"><?= $apiKey ? 'Anahtarı Yenile' : 'Anahtar Oluştur' ?></button>
    </form>

    <?php if ($apiKey): ?>
    <div class="mt-8">
      <p class="text-sm font-semibold text-white">Kullanım örneği</p>
      <pre class="mt-3 overflow-x-auto rounded-xl border border-ink-700 bg-black/50 p-4 font-mono text-xs leading-relaxed text-slate-300">curl -H "Authorization: Bearer <?= e($apiKey) ?>" \
  <?= e($origin . $basePath . '/api.php') ?></pre>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php render_layout_end();
