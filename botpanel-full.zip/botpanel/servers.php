<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();
$all = pm2_all();

$st = db()->prepare('SELECT * FROM servers WHERE user_id = ? ORDER BY id DESC');
$st->execute([$user['id']]);
$servers = $st->fetchAll();

foreach ($servers as $i => $srv) {
    $servers[$i]['live'] = sync_status($srv, $all);
}

render_layout_start('Botlarım', 'servers');
page_heading('Botlarım', 'Tüm botlarınızı buradan yönetin.');
?>
<div class="mb-6 flex justify-end">
  <a href="create_server.php" class="<?= btn_class() ?>">+ Yeni Bot</a>
</div>

<div id="server-table" data-swap data-poll class="<?= card_class() ?> overflow-hidden p-0">
  <?php if (!$servers): ?>
    <p class="p-10 text-center text-sm text-slate-500">Henüz bot yok.</p>
  <?php else: ?>
  <div class="overflow-x-auto">
    <table class="w-full min-w-[760px] text-left text-sm">
      <thead class="border-b border-ink-700 bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500">
        <tr>
          <th class="px-5 py-3 font-medium">Bot</th>
          <th class="px-5 py-3 font-medium">Tür</th>
          <th class="px-5 py-3 font-medium">Durum</th>
          <th class="px-5 py-3 font-medium">CPU / RAM</th>
          <th class="px-5 py-3 font-medium text-right">İşlemler</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-ink-700">
      <?php foreach ($servers as $s):
          $m = $all[pm2_name((int)$s['id'])] ?? null; ?>
        <tr class="hover:bg-ink-700/20">
          <td class="px-5 py-4">
            <a href="server_detail.php?id=<?= (int)$s['id'] ?>" class="font-semibold text-white hover:text-brand-300"><?= e($s['bot_name']) ?></a>
            <p class="text-xs text-slate-500">#<?= (int)$s['id'] ?> · <?= e($s['main_file']) ?></p>
          </td>
          <td class="px-5 py-4"><?= type_badge($s['bot_type']) ?></td>
          <td class="px-5 py-4"><?= status_badge($s['live']) ?></td>
          <td class="px-5 py-4 font-mono text-xs text-slate-400">
            <?= $m ? round($m['cpu'], 1) . '% · ' . round($m['memory'] / 1048576, 1) . ' MB' : '—' ?>
          </td>
          <td class="px-5 py-4">
            <div class="flex flex-wrap justify-end gap-2">
              <?= action_button((int)$s['id'], 'start', 'Başlat', 'success', 'list') ?>
              <?= action_button((int)$s['id'], 'restart', 'Yeniden', 'warn', 'list') ?>
              <?= action_button((int)$s['id'], 'stop', 'Durdur', 'info', 'list') ?>
              <a href="server_detail.php?id=<?= (int)$s['id'] ?>" class="inline-flex items-center rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-300 ring-1 ring-ink-600 hover:bg-ink-700">Detay</a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php render_layout_end();
