<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('index.php');
}

$errors = [];
$username = '';

if (is_post()) {
    csrf_check();
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $password2 = (string)($_POST['password2'] ?? '');

    if (!preg_match('/^[A-Za-z0-9_]{3,32}$/', $username)) {
        $errors[] = 'Kullanıcı adı 3-32 karakter olmalı; yalnızca harf, rakam ve _ içerebilir.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Şifre en az 8 karakter olmalıdır.';
    }
    if ($password !== $password2) {
        $errors[] = 'Şifreler eşleşmiyor.';
    }

    if (!$errors) {
        try {
            $st = db()->prepare("INSERT INTO users (username, password, role, balance, status) VALUES (?, ?, 'user', 0, 'active')");
            $st->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
            flash('success', 'Kayıt başarılı! Şimdi giriş yapabilirsiniz.');
            redirect('login.php');
        } catch (PDOException $ex) {
            $errors[] = $ex->getCode() === '23000'
                ? 'Bu kullanıcı adı zaten alınmış.'
                : 'Kayıt sırasında bir hata oluştu.';
        }
    }
}

render_auth_start('Kayıt Ol');
?>
<h2 class="mb-6 text-lg font-semibold text-white">Yeni hesap oluşturun</h2>

<?php foreach ($errors as $err): ?>
  <div class="mb-3 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300"><?= e($err) ?></div>
<?php endforeach; ?>

<form method="post" class="space-y-5">
  <?= csrf_field() ?>
  <div>
    <label class="mb-1.5 block text-sm text-slate-400" for="username">Kullanıcı adı</label>
    <input id="username" name="username" value="<?= e($username) ?>" required class="<?= input_class() ?>">
  </div>
  <div>
    <label class="mb-1.5 block text-sm text-slate-400" for="password">Şifre</label>
    <input id="password" name="password" type="password" required minlength="8" autocomplete="new-password" class="<?= input_class() ?>">
  </div>
  <div>
    <label class="mb-1.5 block text-sm text-slate-400" for="password2">Şifre (tekrar)</label>
    <input id="password2" name="password2" type="password" required minlength="8" autocomplete="new-password" class="<?= input_class() ?>">
  </div>
  <button type="submit" class="<?= btn_class() ?> w-full">Hesap Oluştur</button>
</form>

<p class="mt-6 text-center text-sm text-slate-400">
  Zaten hesabınız var mı? <a href="login.php" class="font-semibold text-brand-400 hover:text-brand-300">Giriş yapın</a>
</p>
<?php
render_auth_end();
