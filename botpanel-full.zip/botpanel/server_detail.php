<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();
$id   = (int)($_GET['id'] ?? 0);
$srv  = $id ? fetch_server($id) : null;

if (!$srv || !can_manage($srv, $user)) {
    flash('error', 'Sunucu bulunamadı veya bu sunucuya erişim yetkiniz yok.');
    redirect('servers.php');
}

$all = pm2_all();
$srv['status'] = sync_status($srv, $all);
$m = $all[pm2_name($id)] ?? null;

$files = list_bot_files($srv['folder_path']);
$editName = safe_file_name((string)($_GET['file'] ?? ''));
$editContent = null;
if ($editName !== null && is_file($srv['folder_path'] . '/' . $editName)) {
    $editContent = (string)file_get_contents($srv['folder_path'] . '/' . $editName);
} else {
    $editName = null;
}

$uptime = '—';
if ($m && $m['uptime'] > 0) {
    $secs = max(0, (int)((time() * 1000 - $m['uptime']) / 1000));
    $uptime = sprintf('%dg %02d:%02d', intdiv($secs, 86400), intdiv($secs % 86400, 3600), intdiv($secs % 3600, 60));
}

render_layout_start($srv['bot_name'], $user['role'] === 'admin' ? 'admin_servers' : 'servers');
?>
<div id="server-head" data-swap class="mb-6 flex flex-wrap items-center justify-between gap-4">
  <div>
    <a href="<?= e($user['role'] === 'admin' ? 'admin_servers.php' : 'servers.php') ?>" class="text-sm text-slate-500 hover:text-brand-300">← Listeye dön</a>
    <h1 class="mt-2 flex flex-wrap items-center gap-3 text-2xl font-semibold text-white">
      <?= e($srv['bot_name']) ?> <?= status_badge($srv['status']) ?> <?= type_badge($srv['bot_type']) ?>
    </h1>
    <p class="mt-1 font-mono text-xs text-slate-500">#<?= (int)$srv['id'] ?> · PM2: <?= e(pm2_name($id)) ?></p>
  </div>
  <div class="flex flex-wrap gap-2">
    <?= action_button($id, 'start', 'Başlat', 'success') ?>
    <?= action_button($id, 'restart', 'Yeniden Başlat', 'warn') ?>
    <?= action_button($id, 'stop', 'Durdur', 'info') ?>
    <?= action_button($id, 'delete', 'Sil', 'danger', 'list', 'Bu sunucu ve tüm dosyaları kalıcı olarak silinecek. Emin misiniz?') ?>
  </div>
</div>

<section id="server-stats" data-swap class="mb-8 grid gap-4 md:grid-cols-4">
  <div class="<?= card_class() ?> p-5"><p class="text-xs text-slate-500">CPU</p><p class="mt-1 text-xl font-semibold text-sky-300"><?= $m ? round($m['cpu'], 1) : 0 ?>%</p><p class="text-xs text-slate-600">limit %<?= (int)$srv['cpu_limit'] ?></p></div>
  <div class="<?= card_class() ?> p-5"><p class="text-xs text-slate-500">RAM</p><p class="mt-1 text-xl font-semibold text-violet-300"><?= $m ? round($m['memory'] / 1048576, 1) : 0 ?> MB</p><p class="text-xs text-slate-600">limit <?= (int)$srv['ram_limit'] ?> MB</p></div>
  <div class="<?= card_class() ?> p-5"><p class="text-xs text-slate-500">Çalışma süresi</p><p class="mt-1 text-xl font-semibold text-white"><?= e($uptime) ?></p><p class="text-xs text-slate-600">Yeniden başlatma: <?= $m ? (int)$m['restarts'] : 0 ?></p></div>
  <div class="<?= card_class() ?> p-5"><p class="text-xs text-slate-500">Ana dosya</p><p class="mt-1 font-mono text-lg text-white"><?= e($srv['main_file']) ?></p><p class="truncate text-xs text-slate-600"><?= e(basename($srv['folder_path'])) ?></p></div>
</section>

<section class="grid gap-6 xl:grid-cols-5">
  <div class="<?= card_class() ?> xl:col-span-2">
    <div id="file-list" data-swap>
      <h2 class="mb-4 text-lg font-semibold text-white">Dosya Yöneticisi</h2>
      <ul class="mb-5 max-h-72 space-y-1 overflow-y-auto pr-1">
        <?php if (!$files): ?>
          <li class="text-sm text-slate-500">Dosya bulunamadı.</li>
        <?php endif; ?>
        <?php foreach ($files as $f): $active = $editName === $f['name']; ?>
          <li>
            <a href="server_detail.php?id=<?= $id ?>&file=<?= urlencode($f['name']) ?>" data-nav
               class="flex items-center justify-between rounded-lg px-3 py-2 text-sm transition <?= $active ? 'bg-brand-500/15 text-brand-300 ring-1 ring-brand-500/30' : 'text-slate-300 hover:bg-ink-700/50' ?>">
              <span class="truncate font-mono"><?= e($f['name']) ?><?= $f['name'] === $srv['main_file'] ? ' <span class="text-[10px] text-amber-300">(ana)</span>' : '' ?></span>
              <span class="text-xs text-slate-500"><?= number_format($f['size'] / 1024, 1) ?> KB</span>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>

    <form method="post" action="action.php" data-ajax data-reset class="space-y-3 rounded-xl bg-ink-900/70 p-4">
      <?= csrf_field() ?>
      <input type="hidden" name="server_id" value="<?= $id ?>">
      <input type="hidden" name="do" value="file_create">
      <p class="text-sm font-semibold text-white">Yeni dosya</p>
      <div class="flex gap-2">
        <input name="file" required placeholder="ornek.js / .env / data.json" class="<?= input_class() ?> font-mono">
        <button class="<?= btn_class() ?> shrink-0 px-4">Oluştur</button>
      </div>
      <p class="text-xs text-slate-500">İzinli: <?= e(implode(', ', array_map(fn($x) => '.' . $x, ALLOWED_EXT))) ?></p>
    </form>
  </div>

  <div id="editor-pane" data-swap class="<?= card_class() ?> xl:col-span-3">
    <?php if ($editName === null || $editContent === null): ?>
      <div class="flex h-full min-h-[320px] items-center justify-center text-center text-sm text-slate-500">
        Düzenlemek için soldan bir dosya seçin.
      </div>
    <?php else: ?>
      <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 class="font-mono text-lg text-white"><?= e($editName) ?></h2>
        <?php if ($editName !== $srv['main_file']): ?>
        <form method="post" action="action.php" data-ajax data-confirm="Dosya silinsin mi?">
          <?= csrf_field() ?>
          <input type="hidden" name="server_id" value="<?= $id ?>">
          <input type="hidden" name="do" value="file_delete">
          <input type="hidden" name="file" value="<?= e($editName) ?>">
          <button class="<?= btn_class('danger') ?> !py-1.5 text-xs">Dosyayı Sil</button>
        </form>
        <?php endif; ?>
      </div>
      <form method="post" action="action.php" data-ajax data-save class="space-y-4">
        <?= csrf_field() ?>
        <input type="hidden" name="server_id" value="<?= $id ?>">
        <input type="hidden" name="do" value="file_save">
        <input type="hidden" name="file" value="<?= e($editName) ?>">
        <textarea name="content" spellcheck="false" class="h-80 w-full resize-y rounded-xl border border-ink-600 bg-ink-950 p-4 font-mono text-sm leading-relaxed text-emerald-100 outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/30"><?= e($editContent) ?></textarea>
        <div class="flex flex-wrap items-center justify-end gap-3">
          <p class="mr-auto text-xs text-slate-500">Kısayol: Ctrl+S · Değişikliği uygulamak için botu yeniden başlatın.</p>
          <button class="<?= btn_class() ?>" data-busy="Kaydediliyor…">Kaydet</button>
        </div>
      </form>
    <?php endif; ?>
  </div>
</section>

<section class="<?= card_class() ?> mt-6">
  <div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <h2 class="text-lg font-semibold text-white">Canlı Konsol
      <span class="ml-2 inline-flex items-center gap-1.5 text-xs font-normal text-slate-500"><span id="live-dot" class="h-2 w-2 animate-pulse rounded-full bg-emerald-400"></span> 3 sn'de bir güncellenir</span>
    </h2>
    <div class="flex gap-2">
      <button id="btn-pause" type="button" class="<?= btn_class('ghost') ?> !px-3 !py-1.5 text-xs">Duraklat</button>
      <button id="btn-clear" type="button" class="<?= btn_class('ghost') ?> !px-3 !py-1.5 text-xs">Temizle</button>
    </div>
  </div>
  <pre id="console" class="h-96 overflow-auto whitespace-pre-wrap break-all rounded-xl border border-ink-700 bg-black/60 p-4 font-mono text-xs leading-relaxed text-emerald-300">Konsol yükleniyor...</pre>
</section>

<script>
(() => {
  const sid = <?= (int)$id ?>;
  const out = document.getElementById('console');
  const dot = document.getElementById('live-dot');
  const btnPause = document.getElementById('btn-pause');
  let paused = false;

  async function tick() {
    if (paused) return;
    try {
      const res = await fetch('action.php?do=logs&server_id=' + sid, { cache: 'no-store', credentials: 'same-origin' });
      const data = await res.json();
      if (!data.ok) throw new Error(data.message || 'hata');
      const atBottom = out.scrollTop + out.clientHeight >= out.scrollHeight - 24;
      out.textContent = data.log || '(Henüz log yok)';
      if (atBottom) out.scrollTop = out.scrollHeight;
      dot.classList.toggle('bg-emerald-400', data.status === 'running');
      dot.classList.toggle('bg-red-400', data.status !== 'running');
    } catch (_) {
      dot.classList.add('bg-red-400');
    }
  }

  btnPause.addEventListener('click', () => {
    paused = !paused;
    btnPause.textContent = paused ? 'Devam Et' : 'Duraklat';
    if (!paused) tick();
  });
  document.getElementById('btn-clear').addEventListener('click', () => { out.textContent = ''; });
  document.addEventListener('kt:done', () => tick());

  tick();
  setInterval(tick, 3000);
})();
</script>
<?php render_layout_end();
