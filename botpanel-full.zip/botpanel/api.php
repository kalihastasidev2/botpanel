<?php
/*
 * Karasipahi Tek · Yönetici API'si
 * Kimlik: Authorization: Bearer <anahtar>   veya   X-API-Key: <anahtar>
 * Anahtarları Yönetici Paneli > API Yönetimi sayfasından oluşturun ve yetki seçin.
 *
 * Okuma (GET):
 *   me                         kendi bilgin
 *   users                      müşteri listesi                        [users.read]
 *   servers[?user_id=]         bot listesi                            [servers.read]
 *
 * Yazma (POST, JSON gövde):
 *   user.create                {username, password?, balance?}         [users.write]
 *   user.suspend               {user_id|username, status: active|banned} [users.write]
 *   balance                    {user_id|username, amount, op: add|sub, note?} [balance.write]
 *   server.create              {user_id|username, name, type: nodejs|python, ram?, cpu?, start?, charge?} [servers.write]
 *   server.action              {server_id, do: start|stop|restart|delete} [servers.write]
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

@set_time_limit(120);
header('Cache-Control: no-store');

$token = '';
if (preg_match('/Bearer\s+(\S+)/i', (string)($_SERVER['HTTP_AUTHORIZATION'] ?? ''), $m)) {
    $token = $m[1];
} elseif (!empty($_SERVER['HTTP_X_API_KEY'])) {
    $token = (string)$_SERVER['HTTP_X_API_KEY'];
}
$actor = $token !== '' ? authenticate_api_key($token) : null;
if (!$actor) {
    json_out(['ok' => false, 'message' => 'API anahtarı eksik, geçersiz veya iptal edilmiş.'], 401);
}

$caller    = $actor['user'];
$isAdminKey = $actor['key_id'] !== null;
$actorName  = $isAdminKey ? 'api-key#' . $actor['key_id'] : 'user#' . $caller['id'];
$action     = (string)($_GET['action'] ?? 'me');
$in         = api_input();

try {
    switch ($action) {
        case 'me':
            json_out(['ok' => true, 'data' => api_user_row($caller) + ['scopes' => $actor['scopes']]]);

        case 'users':
            api_need($actor, 'users.read');
            $rows = db()->query('SELECT id, username, role, balance, status, created_at FROM users ORDER BY id')->fetchAll();
            json_out(['ok' => true, 'data' => $rows]);

        case 'user.create':
            api_need($actor, 'users.write');
            api_post();
            json_out(['ok' => true, 'data' => api_create_user($in, $actorName)], 201);

        case 'user.suspend':
            api_need($actor, 'users.write');
            api_post();
            $target = api_target_user($in);
            if ((int)$target['id'] === (int)$caller['id']) {
                throw new RuntimeException('Kendi hesabınızı askıya alamazsınız.');
            }
            $status = (($in['status'] ?? 'banned') === 'active') ? 'active' : 'banned';
            db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$status, $target['id']]);
            add_log(null, "kullanıcı {$status} (user#{$target['id']}, {$actorName})");
            json_out(['ok' => true, 'data' => ['user_id' => (int)$target['id'], 'status' => $status]]);

        case 'balance':
            api_need($actor, 'balance.write');
            api_post();
            $target = api_target_user($in);
            $amount = round((float)str_replace(',', '.', (string)($in['amount'] ?? 0)), 2);
            if ($amount <= 0 || $amount > 100000) {
                throw new RuntimeException('Tutar 0 ile 100000 arasında olmalı.');
            }
            $delta = (($in['op'] ?? 'add') === 'sub') ? -$amount : $amount;
            $note  = mb_substr(trim((string)($in['note'] ?? 'API bakiye işlemi')), 0, 190);
            $new   = change_balance((int)$target['id'], $delta, $note, $actorName);
            add_log(null, sprintf('bakiye %s%.2f (user#%d, %s)', $delta > 0 ? '+' : '-', $amount, $target['id'], $actorName));
            json_out(['ok' => true, 'data' => [
                'user_id' => (int)$target['id'], 'username' => $target['username'],
                'amount' => $delta, 'balance' => $new,
            ]]);

        case 'servers':
            api_need($actor, 'servers.read');
            if ($isAdminKey) {
                $sql = 'SELECT id, user_id, bot_name, bot_type, status, ram_limit, cpu_limit, created_at FROM servers';
                $params = [];
                if (!empty($_GET['user_id'])) {
                    $sql .= ' WHERE user_id = ?';
                    $params[] = (int)$_GET['user_id'];
                }
                $st = db()->prepare($sql . ' ORDER BY id');
                $st->execute($params);
            } else {
                $st = db()->prepare('SELECT id, user_id, bot_name, bot_type, status, ram_limit, cpu_limit, created_at FROM servers WHERE user_id = ? ORDER BY id');
                $st->execute([$caller['id']]);
            }
            $servers = $st->fetchAll();
            $all = pm2_all();
            foreach ($servers as $i => $s) {
                $servers[$i]['id'] = (int)$s['id'];
                $servers[$i]['status'] = sync_status($s, $all);
            }
            json_out(['ok' => true, 'data' => $servers]);

        case 'server.create':
            api_need($actor, 'servers.write');
            api_post();
            $owner = api_target_user($in);
            json_out(['ok' => true, 'data' => api_create_server($owner, $in, $actorName)], 201);

        case 'server.action':
            api_need($actor, 'servers.write');
            api_post();
            $srv = fetch_server((int)($in['server_id'] ?? 0)) ?: throw new RuntimeException('Sunucu bulunamadı.');
            $do  = (string)($in['do'] ?? '');
            if ($do === 'delete') {
                delete_server($srv);
                json_out(['ok' => true, 'message' => 'Sunucu silindi.']);
            }
            if (!in_array($do, ['start', 'stop', 'restart'], true)) {
                throw new RuntimeException('do: start, stop, restart veya delete olmalı.');
            }
            [$ok, $msg] = server_lifecycle($srv, $do);
            add_log((int)$srv['id'], $do . " ({$actorName})" . ($ok ? '' : ' - hata'));
            json_out(['ok' => $ok, 'message' => $msg], $ok ? 200 : 422);

        default:
            json_out(['ok' => false, 'message' => 'Bilinmeyen action.'], 404);
    }
} catch (RuntimeException $ex) {
    json_out(['ok' => false, 'message' => $ex->getMessage()], 422);
} catch (Throwable $t) {
    json_out(['ok' => false, 'message' => 'Sunucu hatası.'], 500);
}

/* ---------------- yardımcılar ---------------- */

function api_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw !== false && trim($raw) !== '') {
        $data = json_decode($raw, true);
        if (is_array($data)) {
            return $data;
        }
    }
    return array_merge($_GET, $_POST);
}

function api_need(array $actor, string $scope): void
{
    if (!in_array($scope, $actor['scopes'], true)) {
        json_out(['ok' => false, 'message' => "Bu anahtarın '{$scope}' yetkisi yok."], 403);
    }
}

function api_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        json_out(['ok' => false, 'message' => 'Bu işlem için POST kullanın.'], 405);
    }
}

function api_user_row(array $u): array
{
    return [
        'id'         => (int)$u['id'],
        'username'   => $u['username'],
        'role'       => $u['role'],
        'balance'    => (float)$u['balance'],
        'created_at' => $u['created_at'],
    ];
}
