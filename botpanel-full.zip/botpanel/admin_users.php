<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$admin = require_admin();

if (is_post()) {
    csrf_check();
    $act = (string)($_POST['act'] ?? '');
    $uid = (int)($_POST['user_id'] ?? 0);

    try {
        switch ($act) {
            case 'add':
                $username = trim((string)($_POST['username'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                $role     = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
                $balance  = max(0.0, round((float)str_replace(',', '.', (string)($_POST['balance'] ?? '0')), 2));

                if (!preg_match('/^[A-Za-z0-9_]{3,32}$/', $username)) {
                    throw new RuntimeException('Kullanıcı adı 3-32 karakter olmalı (harf, rakam, _).');
                }
                if (strlen($password) < 8) {
                    throw new RuntimeException('Şifre en az 8 karakter olmalı.');
                }
                db()->prepare('INSERT INTO users (username, password, role, balance, status) VALUES (?, ?, ?, ?, "active")')
                    ->execute([$username, password_hash($password, PASSWORD_DEFAULT), $role, $balance]);
                add_log(null, "müşteri eklendi: {$username} (admin#{$admin['id']})");
                flash('success', "{$username} hesabı oluşturuldu.");
                break;

            case 'balance':
                $amount = round((float)str_replace(',', '.', (string)($_POST['amount'] ?? '0')), 2);
                $sign   = ($_POST['op'] ?? 'add') === 'sub' ? -1 : 1;
                if ($amount <= 0) {
                    throw new RuntimeException('Tutar sıfırdan büyük olmalı.');
                }
                change_balance($uid, $sign * $amount, 'Panel bakiye işlemi', 'admin#' . $admin['id']);
                add_log(null, sprintf('bakiye %s%.2f (user#%d, admin#%d)', $sign > 0 ? '+' : '-', $amount, $uid, $admin['id']));
                flash('success', 'Bakiye güncellendi.');
                break;

            case 'ban':
                if ($uid === (int)$admin['id']) {
                    throw new RuntimeException('Kendi hesabınızı askıya alamazsınız.');
                }
                $st = db()->prepare('SELECT status FROM users WHERE id = ?');
                $st->execute([$uid]);
                $current = $st->fetchColumn();
                if ($current === false) {
                    throw new RuntimeException('Kullanıcı bulunamadı.');
                }
                $new = $current === 'active' ? 'banned' : 'active';
                db()->prepare('UPDATE users SET status = ? WHERE id = ?')->execute([$new, $uid]);
                add_log(null, "kullanıcı {$new} (user#{$uid}, admin#{$admin['id']})");
                flash('success', $new === 'banned' ? 'Kullanıcı askıya alındı.' : 'Askı kaldırıldı.');
                break;

            case 'delete':
                if ($uid === (int)$admin['id']) {
                    throw new RuntimeException('Kendi hesabınızı silemezsiniz.');
                }
                $st = db()->prepare('SELECT * FROM servers WHERE user_id = ?');
                $st->execute([$uid]);
                foreach ($st->fetchAll() as $srv) {
                    delete_server($srv);
                }
                db()->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]);
                add_log(null, "kullanıcı silindi (user#{$uid}, admin#{$admin['id']})");
                flash('success', 'Kullanıcı ve bağlı tüm veriler silindi.');
                break;

            default:
                throw new RuntimeException('Geçersiz işlem.');
        }
    } catch (PDOException $ex) {
        flash('error', $ex->getCode() === '23000' ? 'Bu kullanıcı adı zaten kullanılıyor.' : 'Veritabanı hatası.');
    } catch (Throwable $t) {
        flash('error', $t->getMessage());
    }
    finish('admin_users.php');
}

$users = db()->query(
    'SELECT u.*, (SELECT COUNT(*) FROM servers s WHERE s.user_id = u.id) AS server_count
     FROM users u ORDER BY u.id DESC'
)->fetchAll();

render_layout_start('Müşteriler', 'admin_users');
page_heading('Müşteri Yönetimi', 'Hesap oluşturun, bakiye yönetin, askıya alın veya silin.');
?>
<div class="grid gap-6 xl:grid-cols-3">
  <form method="post" data-ajax data-reset class="<?= card_class() ?> space-y-4 xl:col-span-1">
    <h2 class="text-lg font-semibold text-white">Yeni Müşteri</h2>
    <?= csrf_field() ?>
    <input type="hidden" name="act" value="add">
    <input name="username" required placeholder="Kullanıcı adı" class="<?= input_class() ?>">
    <input name="password" type="text" required minlength="8" placeholder="Şifre (min. 8)" class="<?= input_class() ?>">
    <div class="grid grid-cols-2 gap-3">
      <select name="role" class="<?= input_class() ?>"><option value="user">Müşteri</option><option value="admin">Yönetici</option></select>
      <input name="balance" inputmode="decimal" value="0" placeholder="Bakiye" class="<?= input_class() ?>">
    </div>
    <button class="<?= btn_class() ?> w-full">Hesap Oluştur</button>
  </form>

  <div id="user-table" data-swap class="<?= card_class() ?> overflow-hidden p-0 xl:col-span-2">
    <div class="overflow-x-auto">
      <table class="w-full min-w-[720px] text-left text-sm">
        <thead class="border-b border-ink-700 bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500">
          <tr><th class="px-5 py-3 font-medium">Kullanıcı</th><th class="px-5 py-3 font-medium">Bakiye</th><th class="px-5 py-3 font-medium">Bot</th><th class="px-5 py-3 font-medium">Durum</th><th class="px-5 py-3 font-medium text-right">İşlemler</th></tr>
        </thead>
        <tbody class="divide-y divide-ink-700">
        <?php foreach ($users as $u): $isSelf = (int)$u['id'] === (int)$admin['id']; ?>
          <tr class="align-top hover:bg-ink-700/20">
            <td class="px-5 py-4">
              <p class="font-semibold text-white"><?= e($u['username']) ?> <?= $u['role'] === 'admin' ? '<span class="ml-1 rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] text-amber-300">ADMIN</span>' : '' ?></p>
              <p class="text-xs text-slate-500">#<?= (int)$u['id'] ?> · <?= e($u['created_at']) ?></p>
            </td>
            <td class="px-5 py-4 font-semibold text-brand-300"><?= e(money((float)$u['balance'])) ?></td>
            <td class="px-5 py-4 text-slate-300"><?= (int)$u['server_count'] ?></td>
            <td class="px-5 py-4">
              <?= $u['status'] === 'active'
                    ? '<span class="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs text-emerald-300 ring-1 ring-emerald-500/30">Aktif</span>'
                    : '<span class="rounded-full bg-red-500/15 px-2.5 py-1 text-xs text-red-300 ring-1 ring-red-500/30">Askıda</span>' ?>
            </td>
            <td class="px-5 py-4">
              <div class="flex flex-col items-end gap-2">
                <?php if (!$isSelf): ?>
                <form method="post" data-ajax class="flex gap-1">
                  <?= csrf_field() ?>
                  <input type="hidden" name="act" value="balance">
                  <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                  <input name="amount" inputmode="decimal" placeholder="Tutar" class="w-20 rounded-lg border border-ink-600 bg-ink-900 px-2 py-1 text-xs text-white outline-none">
                  <select name="op" class="rounded-lg border border-ink-600 bg-ink-900 px-1 py-1 text-xs text-white"><option value="add">+ Ekle</option><option value="sub">− Çıkar</option></select>
                  <button class="rounded-lg bg-sky-500/15 px-2 py-1 text-xs font-semibold text-sky-300 ring-1 ring-sky-500/30">Uygula</button>
                </form>
                <?php endif; ?>
                <div class="flex gap-2">
                  <?php if (!$isSelf): ?>
                  <form method="post" data-ajax>
                    <?= csrf_field() ?>
                    <input type="hidden" name="act" value="ban">
                    <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                    <button class="rounded-lg bg-amber-500/15 px-2.5 py-1 text-xs font-semibold text-amber-300 ring-1 ring-amber-500/30"><?= $u['status'] === 'active' ? 'Askıya Al' : 'Askıyı Kaldır' ?></button>
                  </form>
                  <form method="post" data-ajax data-confirm="Kullanıcı ve tüm botları kalıcı olarak silinecek. Emin misiniz?">
                    <?= csrf_field() ?>
                    <input type="hidden" name="act" value="delete">
                    <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                    <button class="rounded-lg bg-red-500/15 px-2.5 py-1 text-xs font-semibold text-red-300 ring-1 ring-red-500/30">Sil</button>
                  </form>
                  <?php else: ?>
                    <span class="text-xs text-slate-500">Bu sizsiniz</span>
                  <?php endif; ?>
                </div>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php render_layout_end();
