/* Karasipahi Tek - sayfa yenilemeden işlem akışı
 * - form[data-ajax] gönderimleri fetch ile yapılır, sayfa yenilenmez
 * - data-swap verilen bölümler sunucudan taze halleriyle yerinde güncellenir
 * - a[data-nav] bağlantıları sayfayı yenilemeden açılır (History API)
 * - data-poll bölümleri 15 sn'de bir otomatik tazelenir (girdi alanı olmayanlar)
 * - Ctrl+S: form[data-save] gönderir
 */
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  function toast(ok, msg) {
    const box = $('#toasts');
    if (!box) return;
    const el = document.createElement('div');
    el.className = 'pointer-events-auto whitespace-pre-wrap break-words rounded-xl border px-4 py-3 text-sm shadow-xl backdrop-blur transition duration-300 ' +
      (ok ? 'border-emerald-500/40 bg-emerald-950/90 text-emerald-200' : 'border-red-500/40 bg-red-950/90 text-red-200');
    el.textContent = String(msg).slice(0, 600);
    box.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 4500);
  }

  async function refresh(selector = '[data-swap]') {
    const targets = $$(selector).filter(el => el.id);
    if (!targets.length) return;
    try {
      const res = await fetch(location.pathname + location.search, { credentials: 'same-origin', cache: 'no-store' });
      if (!res.ok) return;
      const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
      if (doc.title) document.title = doc.title;
      for (const el of targets) {
        const fresh = doc.getElementById(el.id);
        if (fresh && document.getElementById(el.id) === el) el.replaceWith(fresh);
      }
      bind(document);
    } catch (_) {
      /* ağ hatasında mevcut ekran korunur */
    }
  }

  async function submit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    if (form.dataset.confirm && !confirm(form.dataset.confirm)) return;

    const buttons = $$('button', form);
    buttons.forEach(b => { b.disabled = true; b.dataset.label = b.innerHTML; });
    if (form.dataset.busy && buttons[0]) buttons[0].textContent = form.dataset.busy;

    try {
      const res = await fetch(form.getAttribute('action') || location.pathname + location.search, {
        method: 'POST',
        body: new FormData(form),
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'fetch', 'Accept': 'application/json' },
      });
      let data;
      try {
        data = await res.json();
      } catch (_) {
        data = { ok: false, message: 'Sunucu beklenmeyen bir yanıt döndü (HTTP ' + res.status + ').' };
      }
      toast(!!data.ok, data.message || (data.ok ? 'Tamamlandı.' : 'İşlem başarısız.'));
      document.dispatchEvent(new CustomEvent('kt:done', { detail: data }));

      if (data.ok && data.redirect) {
        location.href = data.redirect;
        return;
      }
      if (data.ok) {
        if (form.hasAttribute('data-reset')) form.reset();
        if (data.url) history.pushState({}, '', data.url);
        await refresh();
      }
    } catch (err) {
      toast(false, 'Bağlantı hatası: ' + err.message);
    } finally {
      buttons.forEach(b => { b.disabled = false; if (b.dataset.label) b.innerHTML = b.dataset.label; });
    }
  }

  function bind(root) {
    $$('form[data-ajax]', root).forEach(f => {
      if (f.dataset.bound) return;
      f.dataset.bound = '1';
      f.addEventListener('submit', submit);
    });
  }

  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a[data-nav]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault();
    history.pushState({}, '', a.getAttribute('href'));
    refresh();
  });

  window.addEventListener('popstate', () => refresh());

  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      const f = $('form[data-save]');
      if (f) { e.preventDefault(); f.requestSubmit(); }
    }
  });

  let polling = false;
  document.addEventListener('DOMContentLoaded', () => {
    bind(document);
    setInterval(async () => {
      if (document.hidden || polling) return;
      polling = true;
      try { await refresh('[data-poll]'); } finally { polling = false; }
    }, 15000);
  });
})();
