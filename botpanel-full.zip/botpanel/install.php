<?php
/*
 * Sihirli Kurulum - Karasipahi Tek Bot Hosting Paneli
 * Kurulumdan sonra bu dosyayı sunucudan silin.
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/helpers.php';

@set_time_limit(0);
ini_set('display_errors', '1');
error_reporting(E_ALL);

const INSTALL_LOCK = __DIR__ . '/install.lock';
const DEFAULT_ADMIN_USER = 'admin';
const DEFAULT_ADMIN_PASS = 'Osman575761.';

if (is_file(INSTALL_LOCK)) {
    http_response_code(403);
    exit('<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif;background:#0b1020;color:#e2e8f0;padding:40px">'
        . '<h2>Kurulum zaten tamamlanmış.</h2><p>Güvenlik için install.php dosyasını sunucudan silin.</p></body>');
}

/* ------------------------------------------------------------------ */
/*  Yardımcılar                                                        */
/* ------------------------------------------------------------------ */

function install_shell_ok(): bool
{
    if (!function_exists('exec')) {
        return false;
    }
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array('exec', $disabled, true);
}

/**
 * Komut çalıştırır. $asRoot true ise ve PHP root değilse sudo -n kullanır.
 */
function install_run(string $cmd, bool $asRoot = false, int $timeout = 600): array
{
    if (!install_shell_ok()) {
        return [1, 'exec() devre dışı.'];
    }
    $isRoot = function_exists('posix_geteuid') ? posix_geteuid() === 0 : false;
    $prefix = ($asRoot && !$isRoot) ? 'sudo -n ' : '';
    $out = [];
    $code = 0;
    exec('timeout ' . $timeout . ' ' . $prefix . 'sh -c ' . escapeshellarg($cmd) . ' 2>&1', $out, $code);
    return [$code, implode("\n", $out)];
}

function try_pdo(?string $db, string $user, string $pass): ?PDO
{
    try {
        $dsn = 'mysql:host=' . DB_HOST_INSTALL . ';port=3306;charset=utf8mb4' . ($db ? ';dbname=' . $db : '');
        return new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    } catch (PDOException) {
        return null;
    }
}

const DB_HOST_INSTALL = 'localhost';

function ensure_mysql(array &$steps): void
{
    [$code] = install_run('command -v mysql || command -v mariadb', false, 20);
    if ($code !== 0) {
        $steps[] = 'MySQL/MariaDB bulunamadı, otomatik kurulum başlatılıyor...';
        if (is_executable('/usr/bin/apt-get')) {
            $cmd = 'DEBIAN_FRONTEND=noninteractive apt-get update -y && '
                 . 'DEBIAN_FRONTEND=noninteractive apt-get install -y mariadb-server mariadb-client';
        } elseif (is_executable('/usr/bin/dnf')) {
            $cmd = 'dnf install -y mariadb-server';
        } elseif (is_executable('/usr/bin/yum')) {
            $cmd = 'yum install -y mariadb-server';
        } else {
            throw new RuntimeException('Desteklenen paket yöneticisi (apt, dnf, yum) bulunamadı.');
        }
        [$c, $out] = install_run($cmd, true, 1200);
        if ($c !== 0) {
            throw new RuntimeException("MariaDB kurulumu başarısız:\n" . $out);
        }
        $steps[] = 'MariaDB paketleri kuruldu.';
    } else {
        $steps[] = 'MySQL/MariaDB zaten kurulu.';
    }

    install_run(
        'systemctl enable --now mariadb || systemctl enable --now mysql || service mariadb start || service mysql start',
        true,
        120
    );
    $steps[] = 'Veritabanı servisi başlatıldı.';
}

function set_root_password(string $pw, array &$steps): void
{
    $statements = [
        "ALTER USER 'root'@'localhost' IDENTIFIED VIA mysql_native_password USING PASSWORD('$pw')",
        "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$pw'",
        "SET PASSWORD FOR 'root'@'localhost' = PASSWORD('$pw')",
    ];
    $last = '';
    foreach ($statements as $sql) {
        [$code, $out] = install_run('mysql -uroot -e ' . escapeshellarg($sql . '; FLUSH PRIVILEGES;'), true, 60);
        if ($code === 0) {
            $steps[] = 'MySQL root şifresi ayarlandı.';
            return;
        }
        $last = $out;
    }
    throw new RuntimeException("Root şifresi ayarlanamadı. Mevcut root şifrenizi girip tekrar deneyin.\n" . $last);
}

function create_database_and_user(PDO $root, string $db, string $user, string $pass): void
{
    $root->exec("CREATE DATABASE IF NOT EXISTS `{$db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $q = $root->quote($pass);
    $root->exec("CREATE USER IF NOT EXISTS '{$user}'@'localhost' IDENTIFIED BY {$q}");
    $root->exec("ALTER USER '{$user}'@'localhost' IDENTIFIED BY {$q}");
    $root->exec("GRANT ALL PRIVILEGES ON `{$db}`.* TO '{$user}'@'localhost'");
    $root->exec('FLUSH PRIVILEGES');
}

function create_schema(PDO $pdo): void
{
    $tables = [
        "CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(32) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin','user') NOT NULL DEFAULT 'user',
            balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            status ENUM('active','banned') NOT NULL DEFAULT 'active',
            api_key CHAR(64) NULL UNIQUE,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS servers (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            bot_name VARCHAR(64) NOT NULL,
            bot_type ENUM('nodejs','python') NOT NULL,
            folder_path VARCHAR(255) NOT NULL,
            main_file VARCHAR(100) NOT NULL,
            status ENUM('running','stopped','error') NOT NULL DEFAULT 'stopped',
            ram_limit INT UNSIGNED NOT NULL DEFAULT 256,
            cpu_limit INT UNSIGNED NOT NULL DEFAULT 100,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_servers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS tickets (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            subject VARCHAR(150) NOT NULL,
            message TEXT NOT NULL,
            status ENUM('open','answered','closed') NOT NULL DEFAULT 'open',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_tickets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS ticket_replies (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            ticket_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            is_admin TINYINT(1) NOT NULL DEFAULT 0,
            message TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_replies_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            server_id INT UNSIGNED NULL,
            action VARCHAR(255) NOT NULL,
            timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_logs_server (server_id),
            CONSTRAINT fk_logs_server FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
}

function ensure_admin(PDO $pdo, string $username, string $password): void
{
    $st = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $st->execute([$username]);
    if ($st->fetch()) {
        return;
    }
    $ins = $pdo->prepare("INSERT INTO users (username, password, role, balance, status) VALUES (?, ?, 'admin', 0, 'active')");
    $ins->execute([$username, password_hash($password, PASSWORD_DEFAULT)]);
}

function pm2_home_default(): string
{
    if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
        $info = posix_getpwuid(posix_geteuid());
        if (!empty($info['dir'])) {
            return $info['dir'] . '/.pm2';
        }
    }
    return '/var/www/.pm2';
}

function install_pm2(array &$steps): void
{
    [$code] = install_run('command -v pm2', false, 20);
    if ($code === 0) {
        $steps[] = 'PM2 zaten kurulu.';
        return;
    }
    [$npm] = install_run('command -v npm', false, 20);
    if ($npm !== 0) {
        $steps[] = 'UYARI: npm bulunamadı. Node.js kurduktan sonra "npm install -g pm2" komutunu çalıştırın.';
        return;
    }
    [$c, $out] = install_run('npm install -g pm2', true, 600);
    $steps[] = $c === 0 ? 'PM2 global olarak kuruldu.' : "UYARI: PM2 kurulamadı:\n" . $out;
}

function build_config(array $c): string
{
    $lines = [
        '<?php',
        '/*',
        ' * Otomatik oluşturuldu: ' . date('Y-m-d H:i:s') . ' (install.php)',
        ' */',
        'declare(strict_types=1);',
        '',
        "define('APP_NAME', " . var_export($c['app_name'], true) . ');',
        "define('DB_HOST', " . var_export($c['db_host'], true) . ');',
        "define('DB_PORT', " . var_export($c['db_port'], true) . ');',
        "define('DB_NAME', " . var_export($c['db_name'], true) . ');',
        "define('DB_USER', " . var_export($c['db_user'], true) . ');',
        "define('DB_PASS', " . var_export($c['db_pass'], true) . ');',
        '',
        "define('SERVERS_DIR', __DIR__ . '/servers_data');",
        "define('PM2_HOME', " . var_export($c['pm2_home'], true) . ');',
        "define('MAX_SERVERS_PER_USER', " . (int)$c['max_servers'] . ');',
        "define('BOT_CREATE_COST', " . number_format((float)$c['bot_cost'], 2, '.', '') . ');',
        '',
    ];
    return implode("\n", $lines);
}

function env_checks(): array
{
    $bin = fn(string $name): bool => install_run("command -v {$name}", false, 10)[0] === 0;
    $isRoot = function_exists('posix_geteuid') && posix_geteuid() === 0;
    return [
        ['PHP 8.1+', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION],
        ['pdo_mysql eklentisi', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? 'Yüklü' : 'Eksik'],
        ['exec() kullanımı', install_shell_ok(), install_shell_ok() ? 'Açık' : 'Kapalı (PM2 ve kurulum çalışmaz)'],
        ['Root / sudo yetkisi', $isRoot || install_run('sudo -n true', false, 10)[0] === 0, $isRoot ? 'root' : 'sudo -n kontrol edildi'],
        ['MySQL / MariaDB', $bin('mysql') || $bin('mariadb'), ($bin('mysql') || $bin('mariadb')) ? 'Mevcut' : 'Bulunamadı (otomatik kurulabilir)'],
        ['Node.js', $bin('node'), $bin('node') ? 'Mevcut' : 'Bulunamadı'],
        ['PM2', $bin('pm2'), $bin('pm2') ? 'Mevcut' : 'Bulunamadı (kurulum seçeneği ile eklenebilir)'],
        ['Python 3', $bin('python3'), $bin('python3') ? 'Mevcut' : 'Bulunamadı'],
    ];
}

/* ------------------------------------------------------------------ */
/*  Form işleme                                                        */
/* ------------------------------------------------------------------ */

$steps = [];
$error = null;
$success = false;
$generatedRoot = null;
$summary = [];

if (is_post()) {
    try {
        $dbName    = preg_replace('/[^A-Za-z0-9_]/', '', (string)($_POST['db_name'] ?? 'botpanel')) ?: 'botpanel';
        $dbUser    = preg_replace('/[^A-Za-z0-9_]/', '', (string)($_POST['db_user'] ?? 'botpanel')) ?: 'botpanel';
        $dbPass    = (string)($_POST['db_pass'] ?? '');
        $dbPass    = $dbPass !== '' ? $dbPass : bin2hex(random_bytes(12));
        $rootPass  = (string)($_POST['root_pass'] ?? '');
        $adminUser = trim((string)($_POST['admin_user'] ?? DEFAULT_ADMIN_USER));
        $adminPass = (string)($_POST['admin_pass'] ?? DEFAULT_ADMIN_PASS);
        $auto      = isset($_POST['auto_install']);
        $withPm2   = isset($_POST['install_pm2']);

        if (!preg_match('/^[A-Za-z0-9_]{3,32}$/', $adminUser)) {
            throw new RuntimeException('Admin kullanıcı adı 3-32 karakter olmalı (harf, rakam, _).');
        }
        if (strlen($adminPass) < 8) {
            throw new RuntimeException('Admin şifresi en az 8 karakter olmalı.');
        }
        if (version_compare(PHP_VERSION, '8.1.0', '<')) {
            throw new RuntimeException('PHP 8.1 veya üzeri gereklidir.');
        }
        if (!extension_loaded('pdo_mysql')) {
            throw new RuntimeException('pdo_mysql eklentisi yüklü değil.');
        }

        // 1) Mevcut uygulama kullanıcısıyla bağlanmayı dene
        $app = try_pdo($dbName, $dbUser, $dbPass);
        if ($app) {
            $steps[] = 'Mevcut veritabanı bağlantısı kullanılıyor.';
        } else {
            // 2) Root ile bağlanmayı dene
            $root = try_pdo(null, 'root', $rootPass);

            // 3) Bağlanılamıyorsa otomatik kurulum
            if (!$root) {
                if (!$auto) {
                    throw new RuntimeException('MySQL bağlantısı kurulamadı. Root şifresini girin veya "Otomatik kurulum" seçeneğini açın.');
                }
                ensure_mysql($steps);
                $generatedRoot = $rootPass !== '' ? $rootPass : bin2hex(random_bytes(12));
                set_root_password($generatedRoot, $steps);
                $root = try_pdo(null, 'root', $generatedRoot)
                    ?? throw new RuntimeException('Root girişi doğrulanamadı.');
            }

            create_database_and_user($root, $dbName, $dbUser, $dbPass);
            $steps[] = "Veritabanı '{$dbName}' ve kullanıcı '{$dbUser}' hazır.";

            $app = try_pdo($dbName, $dbUser, $dbPass)
                ?? throw new RuntimeException('Uygulama kullanıcısı ile bağlantı kurulamadı.');
        }

        create_schema($app);
        $steps[] = 'Tablolar oluşturuldu.';

        ensure_admin($app, $adminUser, $adminPass);
        $steps[] = "Admin hesabı hazır: {$adminUser}";

        // Sunucu verileri klasörü
        $serversDir = __DIR__ . '/servers_data';
        if (!is_dir($serversDir) && !mkdir($serversDir, 0755, true)) {
            throw new RuntimeException('servers_data klasörü oluşturulamadı.');
        }
        file_put_contents($serversDir . '/.htaccess', "Require all denied\nDeny from all\n");
        file_put_contents($serversDir . '/index.php', "<?php http_response_code(403);\n");
        $steps[] = 'servers_data klasörü hazırlandı.';

        if ($withPm2) {
            install_pm2($steps);
        }

        $config = build_config([
            'app_name'    => 'Karasipahi Tek',
            'db_host'     => DB_HOST_INSTALL,
            'db_port'     => '3306',
            'db_name'     => $dbName,
            'db_user'     => $dbUser,
            'db_pass'     => $dbPass,
            'pm2_home'    => pm2_home_default(),
            'max_servers' => 5,
            'bot_cost'    => 25.00,
        ]);
        if (file_put_contents(__DIR__ . '/config.php', $config) === false) {
            throw new RuntimeException('config.php yazılamadı. Klasör yetkilerini kontrol edin.');
        }
        $steps[] = 'config.php oluşturuldu.';

        file_put_contents(INSTALL_LOCK, date('c'));
        $steps[] = 'Kurulum kilidi oluşturuldu.';

        $success = true;
        $summary = [
            'admin_user' => $adminUser,
            'admin_pass' => $adminPass,
            'db_name'    => $dbName,
            'db_user'    => $dbUser,
            'db_pass'    => $dbPass,
        ];
    } catch (Throwable $t) {
        $error = $t->getMessage();
    }
}

$checks = env_checks();
$defaultDbPass = '';
?>
<!doctype html>
<html lang="tr" class="dark">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sihirli Kurulum · Karasipahi Tek</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = { darkMode: 'class', theme: { extend: {
      colors: {
        brand: { 400: '#34d399', 500: '#10b981', 600: '#059669' },
        ink:   { 950: '#060913', 900: '#0b1020', 800: '#111a2e', 700: '#1e2a44', 600: '#2b3a5c' }
      }
    } } };
  </script>
  <style>body{background:radial-gradient(1100px 500px at 0% -10%,rgba(16,185,129,.12),transparent 60%),#0b1020}</style>
</head>
<body class="min-h-screen font-sans text-slate-200 antialiased">
<div class="mx-auto max-w-4xl p-4 md:p-10">
  <div class="mb-8 flex items-center gap-4">
    <div class="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-400 to-emerald-700 text-lg font-bold text-ink-950">KT</div>
    <div>
      <h1 class="text-2xl font-semibold text-white">Sihirli Kurulum</h1>
      <p class="text-sm text-slate-400">MySQL/MariaDB, veritabanı, tablolar ve admin hesabı tek adımda hazırlanır.</p>
    </div>
  </div>

<?php if ($success): ?>
  <div class="rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-6">
    <h2 class="text-xl font-semibold text-emerald-300">Kurulum başarıyla tamamlandı</h2>
    <div class="mt-5 grid gap-3 text-sm md:grid-cols-2">
      <div class="rounded-xl bg-ink-900/70 p-4"><p class="text-slate-500">Admin kullanıcı adı</p><p class="font-mono text-white"><?= e($summary['admin_user']) ?></p></div>
      <div class="rounded-xl bg-ink-900/70 p-4"><p class="text-slate-500">Admin şifresi</p><p class="font-mono text-white"><?= e($summary['admin_pass']) ?></p></div>
      <div class="rounded-xl bg-ink-900/70 p-4"><p class="text-slate-500">Veritabanı</p><p class="font-mono text-white"><?= e($summary['db_name']) ?> (<?= e($summary['db_user']) ?>)</p></div>
      <div class="rounded-xl bg-ink-900/70 p-4"><p class="text-slate-500">Veritabanı şifresi</p><p class="break-all font-mono text-white"><?= e($summary['db_pass']) ?></p></div>
      <?php if ($generatedRoot): ?>
      <div class="rounded-xl bg-ink-900/70 p-4 md:col-span-2"><p class="text-slate-500">MySQL root şifresi (kaydedin)</p><p class="break-all font-mono text-amber-300"><?= e($generatedRoot) ?></p></div>
      <?php endif; ?>
    </div>
    <p class="mt-5 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm text-amber-200">
      Güvenlik için <code class="font-mono">install.php</code> dosyasını hemen silin ve admin şifresini değiştirin.
    </p>
    <a href="login.php" class="mt-6 inline-flex rounded-xl bg-brand-500 px-5 py-2.5 text-sm font-semibold text-ink-950 hover:bg-brand-400">Panele Giriş Yap</a>
  </div>
<?php else: ?>

  <?php if ($error): ?>
  <div class="mb-6 rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-300">
    <p class="font-semibold">Kurulum hatası</p>
    <pre class="mt-2 whitespace-pre-wrap font-mono text-xs"><?= e($error) ?></pre>
  </div>
  <?php endif; ?>

  <div class="mb-6 rounded-2xl border border-ink-700 bg-ink-800/60 p-6">
    <h2 class="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">Sunucu ön kontrolü</h2>
    <ul class="grid gap-2 text-sm md:grid-cols-2">
      <?php foreach ($checks as [$label, $ok, $detail]): ?>
      <li class="flex items-center justify-between rounded-lg bg-ink-900/70 px-3 py-2">
        <span><?= e($label) ?></span>
        <span class="text-xs <?= $ok ? 'text-emerald-300' : 'text-amber-300' ?>"><?= e($detail) ?></span>
      </li>
      <?php endforeach; ?>
    </ul>
  </div>

  <form method="post" class="space-y-6 rounded-2xl border border-ink-700 bg-ink-800/60 p-6 shadow-xl shadow-black/20">
    <div>
      <h2 class="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">Veritabanı</h2>
      <div class="grid gap-4 md:grid-cols-2">
        <label class="block text-sm"><span class="mb-1.5 block text-slate-400">Veritabanı adı</span>
          <input name="db_name" value="botpanel" class="w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"></label>
        <label class="block text-sm"><span class="mb-1.5 block text-slate-400">Uygulama kullanıcısı</span>
          <input name="db_user" value="botpanel" class="w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"></label>
        <label class="block text-sm"><span class="mb-1.5 block text-slate-400">Uygulama şifresi <span class="text-slate-600">(boş bırakılırsa üretilir)</span></span>
          <input name="db_pass" type="text" placeholder="Otomatik" class="w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"></label>
        <label class="block text-sm"><span class="mb-1.5 block text-slate-400">MySQL root şifresi <span class="text-slate-600">(varsa)</span></span>
          <input name="root_pass" type="password" autocomplete="new-password" class="w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"></label>
      </div>
      <label class="mt-4 flex items-start gap-3 rounded-xl bg-ink-900/70 p-4 text-sm">
        <input type="checkbox" name="auto_install" checked class="mt-1 h-4 w-4 accent-emerald-500">
        <span><span class="block font-semibold text-white">MySQL/MariaDB otomatik kurulsun</span>
          <span class="text-slate-400">Bağlantı kurulamazsa servis kurulur, root şifresi ayarlanır. Bu işlem root/sudo yetkisi gerektirir.</span></span>
      </label>
    </div>

    <div>
      <h2 class="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">Yönetici Hesabı</h2>
      <div class="grid gap-4 md:grid-cols-2">
        <label class="block text-sm"><span class="mb-1.5 block text-slate-400">Kullanıcı adı</span>
          <input name="admin_user" value="<?= e(DEFAULT_ADMIN_USER) ?>" class="w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"></label>
        <label class="block text-sm"><span class="mb-1.5 block text-slate-400">Şifre</span>
          <input name="admin_pass" type="text" value="<?= e(DEFAULT_ADMIN_PASS) ?>" class="w-full rounded-xl border border-ink-600 bg-ink-900 px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"></label>
      </div>
    </div>

    <div>
      <h2 class="mb-4 text-sm font-semibold uppercase tracking-wider text-slate-400">Bot Çalıştırıcı</h2>
      <label class="flex items-start gap-3 rounded-xl bg-ink-900/70 p-4 text-sm">
        <input type="checkbox" name="install_pm2" checked class="mt-1 h-4 w-4 accent-emerald-500">
        <span><span class="block font-semibold text-white">PM2 yoksa global kurulsun</span>
          <span class="text-slate-400">npm mevcutsa "npm install -g pm2" çalıştırılır.</span></span>
      </label>
    </div>

    <button type="submit" class="w-full rounded-xl bg-brand-500 px-5 py-3 text-sm font-semibold text-ink-950 shadow-lg shadow-emerald-900/30 transition hover:bg-brand-400">Kurulumu Başlat</button>
  </form>
<?php endif; ?>

<?php if (!empty($steps)): ?>
  <div class="mt-6 rounded-2xl border border-ink-700 bg-ink-900/70 p-6">
    <h2 class="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-400">Kurulum günlüğü</h2>
    <ol class="list-decimal space-y-1 pl-5 font-mono text-xs text-slate-300">
      <?php foreach ($steps as $s): ?><li><?= e($s) ?></li><?php endforeach; ?>
    </ol>
  </div>
<?php endif; ?>
</div>
</body>
</html>
