<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    add_log(null, 'çıkış yapıldı (user#' . (int)($_SESSION['uid'] ?? 0) . ')');
}
logout_user();
start_session_safe();
flash('success', 'Başarıyla çıkış yaptınız.');
redirect('login.php');
