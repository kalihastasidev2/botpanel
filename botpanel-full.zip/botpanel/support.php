<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();
$ticketId = (int)($_GET['id'] ?? 0);

// Talep oluşturma
if (is_post() && ($_POST['form'] ?? '') === 'new') {
    csrf_check();
    $subject = trim((string)($_POST['subject'] ?? ''));
    $message = trim((string)($_POST['message'] ?? ''));

    if (mb_strlen($subject) < 3 || mb_strlen($subject) > 150) {
        flash('error', 'Konu 3-150 karakter olmalıdır.');
    } elseif (mb_strlen($message) < 10 || mb_strlen($message) > 5000) {
        flash('error', 'Mesaj 10-5000 karakter olmalıdır.');
    } else {
        db()->prepare('INSERT INTO tickets (user_id, subject, message, status) VALUES (?, ?, ?, ?)')
            ->execute([$user['id'], $subject, $message, 'open']);
        $newId = (int)db()->lastInsertId();
        add_log(null, 'destek talebi açıldı #' . $newId . ' (user#' . $user['id'] . ')');
        flash('success', 'Talebiniz alındı. Ekibimiz en kısa sürede dönüş yapacak.');
        redirect('support.php?id=' . $newId);
    }
    redirect('support.php');
}

// Yanıt gönderme
if (is_post() && ($_POST['form'] ?? '') === 'reply') {
    csrf_check();
    $tid = (int)($_POST['ticket_id'] ?? 0);
    $message = trim((string)($_POST['message'] ?? ''));

    $st = db()->prepare('SELECT * FROM tickets WHERE id = ? AND user_id = ?');
    $st->execute([$tid, $user['id']]);
    $ticket = $st->fetch();

    if (!$ticket) {
        flash('error', 'Talep bulunamadı.');
    } elseif ($ticket['status'] === 'closed') {
        flash('error', 'Bu talep kapatılmış.');
    } elseif (mb_strlen($message) < 2 || mb_strlen($message) > 5000) {
        flash('error', 'Mesaj 2-5000 karakter olmalıdır.');
    } else {
        db()->prepare('INSERT INTO ticket_replies (ticket_id, user_id, is_admin, message) VALUES (?, ?, 0, ?)')
            ->execute([$tid, $user['id'], $message]);
        db()->prepare("UPDATE tickets SET status = 'open' WHERE id = ?")->execute([$tid]);
        flash('success', 'Yanıtınız gönderildi.');
    }
    redirect('support.php?id=' . $tid);
}

render_layout_start('Destek Talepleri', 'support');

if ($ticketId > 0):
    $st = db()->prepare('SELECT * FROM tickets WHERE id = ? AND user_id = ?');
    $st->execute([$ticketId, $user['id']]);
    $ticket = $st->fetch();

    if (!$ticket):
        page_heading('Talep bulunamadı');
        echo '<a href="support.php" class="text-brand-400">← Taleplere dön</a>';
    else:
        $rs = db()->prepare('SELECT * FROM ticket_replies WHERE ticket_id = ? ORDER BY id');
        $rs->execute([$ticketId]);
        $replies = $rs->fetchAll();
        ?>
        <div class="mb-6">
          <a href="support.php" class="text-sm text-slate-500 hover:text-brand-300">← Tüm talepler</a>
          <div class="mt-2 flex flex-wrap items-center gap-3">
            <h1 class="text-2xl font-semibold text-white"><?= e($ticket['subject']) ?></h1>
            <?= ticket_status_badge($ticket['status']) ?>
          </div>
        </div>

        <?php render_thread($ticket, $replies, false); ?>

        <?php if ($ticket['status'] !== 'closed'): ?>
        <form method="post" class="<?= card_class() ?> mt-6 space-y-4">
          <?= csrf_field() ?>
          <input type="hidden" name="form" value="reply">
          <input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
          <label class="block text-sm text-slate-400" for="msg">Yanıtınız</label>
          <textarea id="msg" name="message" rows="4" required maxlength="5000" class="<?= input_class() ?>"></textarea>
          <div class="flex justify-end"><button class="<?= btn_class() ?>">Yanıtı Gönder</button></div>
        </form>
        <?php else: ?>
          <p class="mt-6 rounded-xl bg-ink-900/70 p-4 text-center text-sm text-slate-500">Bu talep kapatılmıştır.</p>
        <?php endif; ?>
    <?php endif;
else:
    $st = db()->prepare('SELECT * FROM tickets WHERE user_id = ? ORDER BY id DESC');
    $st->execute([$user['id']]);
    $tickets = $st->fetchAll();
    page_heading('Destek Talepleri', 'Sorunlarınızı bildirin, yanıtlarınızı buradan takip edin.');
    ?>
    <div class="grid gap-6 xl:grid-cols-3">
      <form method="post" class="<?= card_class() ?> space-y-4 xl:col-span-1">
        <h2 class="text-lg font-semibold text-white">Yeni talep</h2>
        <input type="hidden" name="form" value="new">
        <?= csrf_field() ?>
        <input name="subject" required maxlength="150" placeholder="Konu (örn: Bot başlamıyor)" class="<?= input_class() ?>">
        <textarea name="message" required rows="7" maxlength="5000" placeholder="Sorunu detaylı anlatın: hata mesajı, bot türü, ne zaman başladı..." class="<?= input_class() ?>"></textarea>
        <button class="<?= btn_class() ?> w-full">Talep Gönder</button>
      </form>

      <div class="<?= card_class() ?> xl:col-span-2 overflow-hidden p-0">
        <?php if (!$tickets): ?>
          <p class="p-10 text-center text-sm text-slate-500">Henüz destek talebiniz yok.</p>
        <?php else: ?>
        <ul class="divide-y divide-ink-700">
          <?php foreach ($tickets as $t): ?>
          <li>
            <a href="support.php?id=<?= (int)$t['id'] ?>" class="flex items-center justify-between gap-4 px-6 py-4 hover:bg-ink-700/30">
              <div class="min-w-0">
                <p class="truncate font-semibold text-white"><?= e($t['subject']) ?></p>
                <p class="text-xs text-slate-500">#<?= (int)$t['id'] ?> · <?= e($t['created_at']) ?></p>
              </div>
              <?= ticket_status_badge($t['status']) ?>
            </a>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
      </div>
    </div>
<?php endif;

render_layout_end();
