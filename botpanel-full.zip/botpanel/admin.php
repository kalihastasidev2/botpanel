<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$admin = require_admin();
$all = pm2_all();

$stats = [
    'users'    => (int)db()->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn(),
    'banned'   => (int)db()->query("SELECT COUNT(*) FROM users WHERE status = 'banned'")->fetchColumn(),
    'servers'  => (int)db()->query('SELECT COUNT(*) FROM servers')->fetchColumn(),
    'balance'  => (float)db()->query('SELECT COALESCE(SUM(balance),0) FROM users')->fetchColumn(),
    'tickets'  => (int)db()->query("SELECT COUNT(*) FROM tickets WHERE status = 'open'")->fetchColumn(),
];

$servers = db()->query(
    'SELECT s.*, u.username FROM servers s JOIN users u ON u.id = s.user_id ORDER BY s.id DESC LIMIT 200'
)->fetchAll();

$running = 0;
$cpu = 0.0;
$ram = 0;
foreach ($servers as $i => $s) {
    $servers[$i]['live'] = sync_status($s, $all);
    if ($servers[$i]['live'] === 'running') {
        $running++;
    }
    $m = $all[pm2_name((int)$s['id'])] ?? null;
    if ($m) {
        $cpu += $m['cpu'];
        $ram += $m['memory'];
    }
}

$logs = db()->query(
    'SELECT l.action, l.timestamp, s.bot_name FROM logs l LEFT JOIN servers s ON s.id = l.server_id ORDER BY l.id DESC LIMIT 15'
)->fetchAll();

render_layout_start('Yönetim Paneli', 'admin');
page_heading('Yönetim Paneli', 'Sistem geneli istatistikler ve son hareketler.');
?>
<section class="grid gap-5 md:grid-cols-2 xl:grid-cols-5">
  <div class="<?= card_class() ?>"><p class="text-xs text-slate-500">Müşteri</p><p class="mt-2 text-3xl font-semibold text-white"><?= $stats['users'] ?></p><p class="mt-1 text-xs text-red-400"><?= $stats['banned'] ?> askıda</p></div>
  <div class="<?= card_class() ?>"><p class="text-xs text-slate-500">Toplam Sunucu</p><p class="mt-2 text-3xl font-semibold text-white"><?= $stats['servers'] ?></p><p class="mt-1 text-xs text-emerald-400"><?= $running ?> çalışıyor</p></div>
  <div class="<?= card_class() ?>"><p class="text-xs text-slate-500">Toplam CPU</p><p class="mt-2 text-3xl font-semibold text-sky-300"><?= round($cpu, 1) ?>%</p><p class="mt-1 text-xs text-slate-500">PM2 canlı</p></div>
  <div class="<?= card_class() ?>"><p class="text-xs text-slate-500">Toplam RAM</p><p class="mt-2 text-3xl font-semibold text-violet-300"><?= round($ram / 1048576, 1) ?> MB</p><p class="mt-1 text-xs text-slate-500">PM2 canlı</p></div>
  <div class="<?= card_class() ?>"><p class="text-xs text-slate-500">Açık Destek Talebi</p><p class="mt-2 text-3xl font-semibold text-amber-300"><?= $stats['tickets'] ?></p><p class="mt-1 text-xs text-slate-500">Toplam bakiye: <?= e(money($stats['balance'])) ?></p></div>
</section>

<section class="mt-8 grid gap-6 xl:grid-cols-3">
  <div class="<?= card_class() ?> xl:col-span-2 overflow-hidden p-0">
    <div class="flex items-center justify-between border-b border-ink-700 px-6 py-4">
      <h2 class="font-semibold text-white">Son Sunucular</h2>
      <a href="admin_servers.php" class="text-sm text-brand-400 hover:text-brand-300">Tümü →</a>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full text-left text-sm">
        <thead class="bg-ink-900/60 text-xs uppercase tracking-wider text-slate-500"><tr><th class="px-6 py-3 font-medium">Bot</th><th class="px-6 py-3 font-medium">Sahip</th><th class="px-6 py-3 font-medium">Tür</th><th class="px-6 py-3 font-medium">Durum</th></tr></thead>
        <tbody class="divide-y divide-ink-700">
          <?php foreach (array_slice($servers, 0, 8) as $s): ?>
          <tr>
            <td class="px-6 py-3 font-semibold text-white"><?= e($s['bot_name']) ?></td>
            <td class="px-6 py-3 text-slate-400"><?= e($s['username']) ?></td>
            <td class="px-6 py-3"><?= type_badge($s['bot_type']) ?></td>
            <td class="px-6 py-3"><?= status_badge($s['live']) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$servers): ?><tr><td colspan="4" class="px-6 py-8 text-center text-slate-500">Sunucu yok.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="<?= card_class() ?>">
    <h2 class="mb-4 font-semibold text-white">Sistem Logları</h2>
    <ul class="space-y-3 text-xs">
      <?php foreach ($logs as $l): ?>
      <li class="rounded-lg bg-ink-900/70 p-3">
        <p class="font-mono text-slate-300"><?= e($l['action']) ?></p>
        <p class="mt-1 text-slate-500"><?= e($l['timestamp']) ?><?= $l['bot_name'] ? ' · ' . e($l['bot_name']) : '' ?></p>
      </li>
      <?php endforeach; ?>
      <?php if (!$logs): ?><li class="text-slate-500">Kayıt yok.</li><?php endif; ?>
    </ul>
  </div>
</section>
<?php render_layout_end();
