<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

@set_time_limit(0);

$user = require_login();
$do   = (string)($_REQUEST['do'] ?? '');
$sid  = (int)($_REQUEST['server_id'] ?? 0);
$srv  = $sid > 0 ? fetch_server($sid) : null;

// Canlı konsol (salt okunur, JSON)
if ($do === 'logs') {
    if (!$srv || !can_manage($srv, $user)) {
        json_out(['ok' => false, 'message' => 'Yetkisiz erişim.'], 403);
    }
    $all = pm2_all();
    $m   = $all[pm2_name($sid)] ?? null;
    json_out([
        'ok'     => true,
        'log'    => shell_available() ? pm2_logs($sid) : 'exec() devre dışı; konsol kullanılamıyor.',
        'status' => sync_status($srv, $all),
        'cpu'    => $m['cpu'] ?? 0,
        'memory' => $m['memory'] ?? 0,
    ]);
}

if (!is_post()) {
    redirect('servers.php');
}
csrf_check();

if (!$srv || !can_manage($srv, $user)) {
    flash('error', 'Sunucu bulunamadı veya yetkiniz yok.');
    finish('servers.php');
}

$who    = ($user['role'] === 'admin' ? 'admin' : 'user') . '#' . $user['id'];
$detail = 'server_detail.php?id=' . $sid;
$back   = match ((string)($_POST['back'] ?? 'detail')) {
    'list'  => 'servers.php',
    'admin' => 'admin_servers.php',
    default => $detail,
};

switch ($do) {
    case 'start':
    case 'stop':
    case 'restart':
        [$ok, $msg] = server_lifecycle($srv, $do);
        add_log($sid, $do . ' (' . $who . ')' . ($ok ? '' : ' - hata'));
        flash($ok ? 'success' : 'error', $msg);
        finish($back);

    case 'delete':
        delete_server($srv);
        flash('success', 'Sunucu ve dosyaları silindi.');
        finish('servers.php', ['redirect' => 'servers.php']);

    case 'file_create':
        $name = safe_file_name((string)($_POST['file'] ?? ''));
        if ($name === null) {
            flash('error', 'Geçersiz dosya adı veya uzantı. İzinli: .' . implode(', .', ALLOWED_EXT));
            finish($detail);
        }
        $target = $detail . '&file=' . urlencode($name);
        $path   = $srv['folder_path'] . '/' . $name;
        if (file_exists($path)) {
            flash('error', 'Bu isimde bir dosya zaten var.');
            finish($target);
        }
        $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $seed = match ($ext) {
            'py'                => "# {$name}\n",
            'js', 'mjs', 'cjs'  => "// {$name}\n",
            default             => '',
        };
        if (file_put_contents($path, $seed) === false) {
            flash('error', 'Dosya oluşturulamadı (klasör yetkisini kontrol edin).');
            finish($detail);
        }
        add_log($sid, 'dosya oluşturuldu: ' . $name . ' (' . $who . ')');
        flash('success', "{$name} oluşturuldu.");
        finish($target, ['url' => $target]);

    case 'file_save':
        $name = safe_file_name((string)($_POST['file'] ?? ''));
        if ($name === null || !is_file($srv['folder_path'] . '/' . $name)) {
            flash('error', 'Dosya bulunamadı.');
            finish($detail);
        }
        $content = str_replace(["\r\n", "\r"], "\n", (string)($_POST['content'] ?? ''));
        if (strlen($content) > 2 * 1024 * 1024) {
            flash('error', 'Dosya 2 MB sınırını aşıyor.');
            finish($detail . '&file=' . urlencode($name));
        }
        if (file_put_contents($srv['folder_path'] . '/' . $name, $content) === false) {
            flash('error', 'Dosya kaydedilemedi.');
        } else {
            add_log($sid, 'dosya düzenlendi: ' . $name . ' (' . $who . ')');
            flash('success', "{$name} kaydedildi. Değişikliğin etkili olması için botu yeniden başlatın.");
        }
        finish($detail . '&file=' . urlencode($name));

    case 'file_delete':
        $name = safe_file_name((string)($_POST['file'] ?? ''));
        if ($name === null || $name === $srv['main_file']) {
            flash('error', 'Ana dosya silinemez veya dosya geçersiz.');
            finish($detail);
        }
        $path = $srv['folder_path'] . '/' . $name;
        if (is_file($path) && !is_link($path)) {
            @unlink($path);
            add_log($sid, 'dosya silindi: ' . $name . ' (' . $who . ')');
            flash('success', "{$name} silindi.");
        } else {
            flash('error', 'Dosya bulunamadı.');
        }
        finish($detail, ['url' => $detail]);

    default:
        flash('error', 'Geçersiz işlem.');
        finish($back);
}
