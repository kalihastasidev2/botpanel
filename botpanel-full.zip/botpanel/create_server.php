<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

$user = require_login();
$errors = [];
$form = ['name' => '', 'type' => 'nodejs', 'ram' => 256, 'cpu' => 100];

if (is_post()) {
    csrf_check();

    $form['name'] = trim((string)($_POST['name'] ?? ''));
    $form['type'] = (string)($_POST['type'] ?? '');
    $form['ram']  = (int)($_POST['ram'] ?? 256);
    $form['cpu']  = (int)($_POST['cpu'] ?? 100);

    if (!preg_match('/^[\p{L}\p{N} _-]{3,40}$/u', $form['name'])) {
        $errors[] = 'Bot adı 3-40 karakter olmalı; harf, rakam, boşluk, - ve _ içerebilir.';
    }
    if (!in_array($form['type'], ['nodejs', 'python'], true)) {
        $errors[] = 'Geçerli bir bot türü seçin.';
    }
    if ($form['ram'] < 128 || $form['ram'] > 4096) {
        $errors[] = 'RAM limiti 128 - 4096 MB arasında olmalı.';
    }
    if ($form['cpu'] < 10 || $form['cpu'] > 400) {
        $errors[] = 'CPU limiti %10 - %400 arasında olmalı.';
    }
    if (count_user_servers((int)$user['id']) >= MAX_SERVERS_PER_USER) {
        $errors[] = 'En fazla ' . MAX_SERVERS_PER_USER . ' bot oluşturabilirsiniz.';
    }
    if ((float)$user['balance'] < BOT_CREATE_COST) {
        $errors[] = 'Yetersiz bakiye. Bot oluşturmak için en az ' . money(BOT_CREATE_COST) . ' gerekli.';
    }

    if (!$errors) {
        if (!is_dir(SERVERS_DIR)) {
            mkdir(SERVERS_DIR, 0755, true);
        }

        $pdo = db();
        $folder = null;
        try {
            $pdo->beginTransaction();

            $pdo->prepare('UPDATE users SET balance = balance - ? WHERE id = ? AND balance >= ?')
                ->execute([BOT_CREATE_COST, $user['id'], BOT_CREATE_COST]);

            $folder = SERVERS_DIR . '/' . server_folder_name((int)$user['id'], $form['name']);
            $mainFile = create_bot_files($folder, $form['type'], $form['name']);

            $pdo->prepare(
                'INSERT INTO servers (user_id, bot_name, bot_type, folder_path, main_file, status, ram_limit, cpu_limit)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            )->execute([
                $user['id'], $form['name'], $form['type'], $folder, $mainFile, 'stopped', $form['ram'], $form['cpu'],
            ]);

            $id = (int)$pdo->lastInsertId();
            $pdo->commit();

            add_log($id, 'bot oluşturuldu (' . $form['type'] . ', user#' . $user['id'] . ')');
            flash('success', 'Bot oluşturuldu. Dosyaları düzenleyip botu başlatabilirsiniz.');
            redirect('server_detail.php?id=' . $id);
        } catch (Throwable $t) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if ($folder && is_dir($folder)) {
                rrmdir($folder);
            }
            $errors[] = 'Bot oluşturulamadı: ' . $t->getMessage();
        }
    }
}

render_layout_start('Yeni Bot', 'create');
page_heading('Bot Oluşturma Sihirbazı', 'Adım adım botunuzu yapılandırın. Ücret: ' . money(BOT_CREATE_COST));
?>
<?php foreach ($errors as $err): ?>
  <div class="mb-4 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300"><?= e($err) ?></div>
<?php endforeach; ?>

<form method="post" class="grid gap-6 xl:grid-cols-3">
  <?= csrf_field() ?>

  <div class="<?= card_class() ?> space-y-6 xl:col-span-2">
    <div>
      <p class="mb-2 text-xs font-semibold uppercase tracking-wider text-brand-400">1 · Temel bilgiler</p>
      <label class="mb-1.5 block text-sm text-slate-400" for="name">Bot adı</label>
      <input id="name" name="name" value="<?= e($form['name']) ?>" required maxlength="40" placeholder="Örn: Karasipahi Duyuru Botu" class="<?= input_class() ?>">
    </div>

    <div>
      <p class="mb-2 text-xs font-semibold uppercase tracking-wider text-brand-400">2 · Bot türü</p>
      <div class="grid gap-3 md:grid-cols-2">
        <label class="cursor-pointer rounded-2xl border border-ink-600 bg-ink-900 p-5 transition has-[:checked]:border-lime-400 has-[:checked]:bg-lime-500/10">
          <input type="radio" name="type" value="nodejs" class="sr-only" <?= $form['type'] === 'nodejs' ? 'checked' : '' ?>>
          <span class="flex items-center justify-between"><span class="font-semibold text-white">Node.js</span><span class="text-xs text-lime-300">index.js</span></span>
          <span class="mt-2 block text-xs text-slate-500">package.json ve dotenv şablonu, npm install otomatik.</span>
        </label>
        <label class="cursor-pointer rounded-2xl border border-ink-600 bg-ink-900 p-5 transition has-[:checked]:border-sky-400 has-[:checked]:bg-sky-500/10">
          <input type="radio" name="type" value="python" class="sr-only" <?= $form['type'] === 'python' ? 'checked' : '' ?>>
          <span class="flex items-center justify-between"><span class="font-semibold text-white">Python</span><span class="text-xs text-sky-300">bot.py</span></span>
          <span class="mt-2 block text-xs text-slate-500">requirements.txt ve python-dotenv şablonu.</span>
        </label>
      </div>
    </div>
  </div>

  <div class="<?= card_class() ?> space-y-6">
    <p class="text-xs font-semibold uppercase tracking-wider text-brand-400">3 · Kaynak limitleri</p>
    <div>
      <label class="mb-1.5 block text-sm text-slate-400" for="ram">RAM limiti (MB)</label>
      <input id="ram" type="number" name="ram" min="128" max="4096" step="64" value="<?= (int)$form['ram'] ?>" class="<?= input_class() ?>">
      <p class="mt-1 text-xs text-slate-500">Limit aşılırsa PM2 süreci otomatik yeniden başlatır.</p>
    </div>
    <div>
      <label class="mb-1.5 block text-sm text-slate-400" for="cpu">CPU limiti (%)</label>
      <input id="cpu" type="number" name="cpu" min="10" max="400" step="10" value="<?= (int)$form['cpu'] ?>" class="<?= input_class() ?>">
      <p class="mt-1 text-xs text-slate-500">100 = bir çekirdek.</p>
    </div>
    <div class="rounded-xl bg-ink-900/70 p-4 text-sm">
      <div class="flex justify-between text-slate-400"><span>Oluşturma ücreti</span><span class="text-white"><?= e(money(BOT_CREATE_COST)) ?></span></div>
      <div class="mt-2 flex justify-between text-slate-400"><span>Mevcut bakiye</span><span class="text-brand-300"><?= e(money((float)$user['balance'])) ?></span></div>
    </div>
    <button type="submit" class="<?= btn_class() ?> w-full" <?= (float)$user['balance'] < BOT_CREATE_COST ? 'disabled' : '' ?>>Botu Oluştur</button>
  </div>
</form>
<?php render_layout_end();
