# Karasipahi Tek · Bot Hosting Paneli

Node.js ve Python botlarını PM2 ile çalıştırır. Dosya yönetimi, canlı konsol, müşteri ve bakiye yönetimi, destek talepleri ve yönetici API'si içerir.

**Gereksinimler (Debian 13 önerilir):** PHP 8.1+ (`pdo_mysql`), Nginx, MariaDB, Node.js 18+ ve PM2, Python 3, Cloudflare Tunnel (`cloudflared`).

---

## 1. Sunucu paketleri

```bash
apt update && apt upgrade -y
apt install -y nginx git unzip curl ca-certificates mariadb-server \
  php-fpm php-cli php-mysql php-mbstring php-xml \
  python3 python3-pip python3-venv nodejs npm
npm install -g pm2
```

PHP sürümünü not edin (Debian 13'te `8.4`):

```bash
php -v
ls /run/php/
```

## 2. Veritabanı

```bash
mysql -uroot
```

MariaDB konsolunda (şifreyi kendiniz seçin):

```sql
ALTER USER 'root'@'localhost' IDENTIFIED BY 'ROOT_SIFRESI';
CREATE DATABASE botpanel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'botpanel'@'localhost' IDENTIFIED BY 'UYGULAMA_SIFRESI';
GRANT ALL PRIVILEGES ON botpanel.* TO 'botpanel'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 3. Dosyaları yerleştirme

```bash
mkdir -p /var/www
unzip botpanel-full.zip -d /root/bp
mv /root/bp/botpanel /var/www/botpanel
chown -R www-data:www-data /var/www/botpanel
chmod 755 /var/www/botpanel
mkdir -p /var/www/.pm2
chown -R www-data:www-data /var/www/.pm2
```

## 4. Nginx

`/etc/nginx/sites-available/botpanel` dosyasını oluşturun:

```nginx
server {
    listen 80 default_server;
    server_name _;
    root /var/www/botpanel;
    index index.php;
    client_max_body_size 4M;

    location ~ ^/(includes|servers_data)/ { deny all; }
    location ~ ^/(config\.php|install\.lock)$ { deny all; }
    location ~ \.(md|lock)$ { deny all; }
    location ~ /\.(?!well-known) { deny all; }

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
        fastcgi_read_timeout 600;
    }
}
```

Etkinleştirin:

```bash
ln -s /etc/nginx/sites-available/botpanel /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
systemctl enable --now php8.4-fpm
```

`fastcgi_read_timeout` satırı, bot ilk başlatıldığında npm/pip kurulumunun zaman aşımına uğramaması için gereklidir.

## 5. Kurulum sihirbazı

Tarayıcıdan (tünel kurulduktan sonra) `https://ALANADI/install.php` adresini açın:

| Alan | Değer |
|---|---|
| Veritabanı adı | `botpanel` |
| Uygulama kullanıcısı | `botpanel` |
| Uygulama şifresi | 2. adımda belirlediğiniz `UYGULAMA_SIFRESI` (boş bırakmayın) |
| MySQL root şifresi | `ROOT_SIFRESI` |
| MySQL/MariaDB otomatik kurulsun | **kaldırın** |
| PM2 yoksa kurulsun | **kaldırın** (zaten kurdunuz) |
| Admin kullanıcı adı / şifre | Kendiniz belirleyin (en az 8 karakter) |

"Kurulum başarıyla tamamlandı" yazısını gördükten sonra sunucudan silin:

```bash
rm /var/www/botpanel/install.php
```

Kurulum `install.lock` dosyası oluşturur. Bu dosya varken `install.php` tekrar çalışmaz.

## 6. Cloudflare Tunnel

Önce `cloudflared` kurulumu (Debian 13'te apt deposu yoktur, .deb kullanılır):

```bash
cd /root
curl -L -o cloudflared.deb https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
apt install -y ./cloudflared.deb
rm -f /root/cloudflared.deb
```

Domain yetkilendirme ve tünel:

```bash
cloudflared tunnel login          # link çıkar, telefonda açıp domaini seçin
cloudflared tunnel create botpanel
UUID=$(cloudflared tunnel list | awk '/botpanel/{print $1}')
DOMAIN=bot.ALANADINIZ.com
cloudflared tunnel route dns botpanel $DOMAIN

mkdir -p /etc/cloudflared
cp /root/.cloudflared/$UUID.json /etc/cloudflared/
cat > /etc/cloudflared/config.yml <<EOF
tunnel: $UUID
credentials-file: /etc/cloudflared/$UUID.json

ingress:
  - hostname: $DOMAIN
    service: http://localhost:80
  - service: http_status:404
EOF

cloudflared --config /etc/cloudflared/config.yml service install
systemctl enable --now cloudflared
systemctl status cloudflared --no-pager
```

Servis `active (running)` olmalı. Bundan sonra `https://$DOMAIN` adresi panele açılır.

## 7. Güvenlik duvarı

```bash
apt install -y ufw
ufw allow OpenSSH
ufw --force enable
```

Port 80 internete açılmaz, trafik tünel üzerinden gelir.

## 8. Bot süreçlerini açılışta başlatma

```bash
env PATH=$PATH:/usr/bin pm2 startup systemd -u www-data --hp /var/www
```

Çıkan `systemctl ...` satırını aynen çalıştırın (başında `sudo` yoksa olduğu gibi). Panelden bir botu başlattıktan sonra:

```bash
su -s /bin/sh www-data -c "PM2_HOME=/var/www/.pm2 pm2 save"
```

---

## Güncelleme (mevcut kurulum)

Yeni paketi çıkarın ve `config.php`, `install.lock` dosyalarına dokunmadan kopyalayın. Zip bu dosyaları içermez:

```bash
rm -rf /root/upd && unzip -o botpanel-full.zip -d /root/upd
cp -r /root/upd/botpanel/. /var/www/botpanel/
chown -R www-data:www-data /var/www/botpanel
systemctl reload nginx
```

Veritabanı tabloları gerekirse otomatik eklenir (`balance_logs`, `api_keys`).

---

## Yönetici paneli özeti

| Sayfa | İşlev |
|---|---|
| Yönetim Paneli | Genel istatistikler, sistem logları |
| Müşteriler | Hesap oluşturma, bakiye ekleme/çıkarma, askıya alma, silme |
| Tüm Sunucular | Tüm botları denetleme, durdurma, silme |
| Destek Yönetimi | Müşteri taleplerini yanıtlama |
| API Yönetimi | Yetkili API anahtarları, uç noktalar, bakiye geçmişi |

## Yönetici API'si

Anahtar: **API Yönetimi** sayfasından oluşturulur, yetkiler anahtara göre seçilir.

| Yetki | İzin verdiği işlemler |
|---|---|
| `users.read` | Müşteri listesi |
| `users.write` | Müşteri oluştur, askıya al/kaldır |
| `balance.write` | Bakiye ekle/çıkar |
| `servers.read` | Bot listesi |
| `servers.write` | Bot oluştur, başlat, durdur, sil |

```bash
curl -X POST "https://ALANADI/api.php?action=balance" \
  -H "Authorization: Bearer ktp_ANAHTAR" -H "Content-Type: application/json" \
  -d '{"username":"musteri1","amount":100,"op":"add","note":"Ödeme"}'
```

Tüm uç noktalar ve örnekler panelde **API Yönetimi** sayfasının altında yer alır.

## Dizin yapısı

```
botpanel/
├── config.php           veritabanı ayarları (kurulum yazar, zipte yoktur)
├── install.php          kurulum sihirbazı (kurulumdan sonra silinir)
├── api.php              yönetici API'si
├── assets/app.js        sayfa yenilemesiz işlem akışı
├── includes/            çekirdek: oturum, PM2, bot, bakiye, API anahtarları, arayüz
├── servers_data/        her botun klasörü (web erişimi kapalı)
└── *.php                panel sayfaları
```

## Güvenlik notları

- Kurulumdan sonra `install.php` silinmiş olmalı.
- Admin şifresini ilk girişte değiştirin (Profil sayfası).
- API anahtarlarını kimseyle paylaşmayın. Şüphe duyduğunuz anahtarı hemen iptal edin.
- Bot klasörleri `0777` yetkisiyle oluşturulur. Yalnızca kendi sunucunuzda ve güvendiğiniz müşterilerle kullanın.
