<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('index.php');
}

$error = null;
$attempts = (int)($_SESSION['login_fails'] ?? 0);

if (is_post()) {
    csrf_check();

    if ($attempts >= 5) {
        $error = 'Çok fazla hatalı deneme. Lütfen tarayıcıyı kapatıp birkaç dakika sonra tekrar deneyin.';
    } else {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        $st = db()->prepare('SELECT id, password, status FROM users WHERE username = ?');
        $st->execute([$username]);
        $row = $st->fetch();

        if ($row && password_verify($password, $row['password'])) {
            if ($row['status'] !== 'active') {
                $error = 'Hesabınız askıya alınmış. Destek ile iletişime geçin.';
            } else {
                unset($_SESSION['login_fails']);
                login_user((int)$row['id']);
                add_log(null, 'giriş yapıldı (user#' . $row['id'] . ')');
                redirect('index.php');
            }
        } else {
            usleep(400000);
            $_SESSION['login_fails'] = $attempts + 1;
            $error = 'Kullanıcı adı veya şifre hatalı.';
        }
    }
}

render_auth_start('Giriş Yap');
?>
<h2 class="mb-6 text-lg font-semibold text-white">Hesabınıza giriş yapın</h2>

<?php if ($error): ?>
  <div class="mb-5 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300"><?= e($error) ?></div>
<?php endif; ?>

<form method="post" class="space-y-5">
  <?= csrf_field() ?>
  <div>
    <label class="mb-1.5 block text-sm text-slate-400" for="username">Kullanıcı adı</label>
    <input id="username" name="username" required autocomplete="username" class="<?= input_class() ?>">
  </div>
  <div>
    <label class="mb-1.5 block text-sm text-slate-400" for="password">Şifre</label>
    <input id="password" name="password" type="password" required autocomplete="current-password" class="<?= input_class() ?>">
  </div>
  <button type="submit" class="<?= btn_class() ?> w-full">Giriş Yap</button>
</form>

<p class="mt-6 text-center text-sm text-slate-400">
  Hesabınız yok mu? <a href="register.php" class="font-semibold text-brand-400 hover:text-brand-300">Kayıt olun</a>
</p>
<?php
render_auth_end();
