<?php
/*
 * Karasipahi Tek · Harici API
 * Kimlik: Authorization: Bearer <api_key>   veya   X-API-Key: <api_key>
 *
 *  GET  api.php?action=me         kendi hesap bilgin
 *  GET  api.php?action=servers    kendi botların (varsayılan)
 *  GET  api.php?action=users      [admin] müşteri listesi
 *  POST api.php?action=balance    [admin] bakiye ekle / çıkar
 *       gövde (JSON veya form): user_id veya username, amount, op (add|sub), note
 */
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

header('Cache-Control: no-store');

$key = '';
if (preg_match('/Bearer\s+([a-f0-9]{64})/i', (string)($_SERVER['HTTP_AUTHORIZATION'] ?? ''), $m)) {
    $key = $m[1];
} elseif (!empty($_SERVER['HTTP_X_API_KEY'])) {
    $key = (string)$_SERVER['HTTP_X_API_KEY'];
}
if (!preg_match('/^[a-f0-9]{64}$/', $key)) {
    json_out(['ok' => false, 'message' => 'API anahtarı eksik veya geçersiz.'], 401);
}

$st = db()->prepare("SELECT * FROM users WHERE api_key = ? AND status = 'active'");
$st->execute([$key]);
$caller = $st->fetch();
if (!$caller) {
    json_out(['ok' => false, 'message' => 'API anahtarı geçersiz veya hesap askıda.'], 401);
}

$action = (string)($_GET['action'] ?? 'servers');
$input  = api_input();

try {
    switch ($action) {
        case 'me':
            json_out(['ok' => true, 'data' => api_user_row($caller)]);

        case 'servers':
            json_out(['ok' => true, 'data' => api_servers((int)$caller['id'])]);

        case 'users':
            api_require_admin($caller);
            $rows = db()->query('SELECT id, username, role, balance, status, created_at FROM users ORDER BY id')->fetchAll();
            json_out(['ok' => true, 'data' => $rows]);

        case 'balance':
            api_require_admin($caller);
            if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
                json_out(['ok' => false, 'message' => 'Bu işlem için POST kullanın.'], 405);
            }
            json_out(['ok' => true, 'data' => api_change_balance($input, $caller)]);

        default:
            json_out(['ok' => false, 'message' => 'Bilinmeyen action.'], 404);
    }
} catch (RuntimeException $ex) {
    json_out(['ok' => false, 'message' => $ex->getMessage()], 422);
} catch (Throwable $t) {
    json_out(['ok' => false, 'message' => 'Sunucu hatası.'], 500);
}

/* ---------------- yardımcılar ---------------- */

function api_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw !== false && trim($raw) !== '') {
        $data = json_decode($raw, true);
        if (is_array($data)) {
            return $data;
        }
    }
    return array_merge($_GET, $_POST);
}

function api_require_admin(array $u): void
{
    if ($u['role'] !== 'admin') {
        json_out(['ok' => false, 'message' => 'Bu işlem için yönetici yetkisi gerekir.'], 403);
    }
}

function api_user_row(array $u): array
{
    return [
        'id'         => (int)$u['id'],
        'username'   => $u['username'],
        'role'       => $u['role'],
        'balance'    => (float)$u['balance'],
        'created_at' => $u['created_at'],
    ];
}

function api_servers(int $userId): array
{
    $st = db()->prepare(
        'SELECT id, bot_name, bot_type, status, ram_limit, cpu_limit, created_at FROM servers WHERE user_id = ? ORDER BY id'
    );
    $st->execute([$userId]);
    $servers = $st->fetchAll();
    $all = pm2_all();
    foreach ($servers as $i => $s) {
        $servers[$i]['id'] = (int)$s['id'];
        $servers[$i]['status'] = sync_status($s, $all);
    }
    return $servers;
}

function api_change_balance(array $in, array $admin): array
{
    if (!empty($in['user_id'])) {
        $st = db()->prepare('SELECT id, username FROM users WHERE id = ?');
        $st->execute([(int)$in['user_id']]);
    } elseif (!empty($in['username'])) {
        $st = db()->prepare('SELECT id, username FROM users WHERE username = ?');
        $st->execute([trim((string)$in['username'])]);
    } else {
        throw new RuntimeException('user_id veya username gerekli.');
    }
    $target = $st->fetch() ?: throw new RuntimeException('Kullanıcı bulunamadı.');

    $amount = round((float)str_replace(',', '.', (string)($in['amount'] ?? 0)), 2);
    if ($amount <= 0 || $amount > 100000) {
        throw new RuntimeException('Tutar 0 ile 100000 arasında olmalı.');
    }
    $delta = (($in['op'] ?? 'add') === 'sub') ? -$amount : $amount;
    $note  = mb_substr(trim((string)($in['note'] ?? 'API bakiye işlemi')), 0, 190);

    $newBalance = change_balance((int)$target['id'], $delta, $note, 'api:' . $admin['username']);
    add_log(null, sprintf('bakiye %s%.2f (user#%d, api:%s)', $delta > 0 ? '+' : '-', $amount, $target['id'], $admin['username']));

    return [
        'user_id'  => (int)$target['id'],
        'username' => $target['username'],
        'amount'   => $delta,
        'balance'  => $newBalance,
    ];
}
